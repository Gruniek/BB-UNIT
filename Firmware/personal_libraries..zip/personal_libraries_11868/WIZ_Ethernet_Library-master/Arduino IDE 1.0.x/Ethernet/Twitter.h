/*
  Twitter.cpp - Arduino library to Post messages to Twitter using OAuth.
  Copyright (c) NeoCat 2010-2011. All right reserved.
  
  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 */

// ver1.2 - Use &lt;Udp.h&gt; to support IDE 0019 or later
// ver1.3 - Support IDE 1.0

#ifndef TWITTER_H
#define TWITTER_H

#include &lt;inttypes.h&gt;
#include &lt;avr/pgmspace.h&gt;
#if defined(ARDUINO) &amp;&amp; ARDUINO &gt; 18   // Arduino 0019 or later
#include &lt;SPI.h&gt;
#endif
#include &lt;Ethernet.h&gt;
#if defined(ARDUINO) &amp;&amp; ARDUINO &lt; 100  // earlier than Arduino 1.0
#include &lt;EthernetDNS.h&gt;
#endif

class Twitter
{
private:
	uint8_t parseStatus;
	int statusCode;
	const char *token;
#if defined(ARDUINO) &amp;&amp; ARDUINO &lt; 100
	Client client;
#else
	EthernetClient client;
#endif
public:
	Twitter(const char *user_and_passwd);
	
	bool post(const char *msg);
	bool checkStatus(Print *debug = NULL);
	int  wait(Print *debug = NULL);
	int  status(void) { return statusCode; }
};

#endif	//TWITTER_H
