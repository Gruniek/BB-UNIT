#ifndef UTIL_H
#define UTIL_H

#define htons(x) ( ((x)&lt;&lt;8) | (((x)&gt;&gt;8)&amp;0xFF) )
#define ntohs(x) htons(x)

#define htonl(x) ( ((x)&lt;&lt;24 &amp; 0xFF000000UL) | \
                   ((x)&lt;&lt; 8 &amp; 0x00FF0000UL) | \
                   ((x)&gt;&gt; 8 &amp; 0x0000FF00UL) | \
                   ((x)&gt;&gt;24 &amp; 0x000000FFUL) )
#define ntohl(x) htonl(x)

#endif
