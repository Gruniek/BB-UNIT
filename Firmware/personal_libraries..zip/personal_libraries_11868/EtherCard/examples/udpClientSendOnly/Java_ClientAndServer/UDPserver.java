import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UDPserver {
	public static void main(String[] args) {
		UDPserver server = new UDPserver(1234);
		server.start();
	}
	private int port;
	private DatagramSocket s;
	
	SimpleDateFormat sdf = new SimpleDateFormat(&quot;yyyy-MM-dd HH:mm:ss&quot;);

	public UDPserver(int port) {
		this.port = port;
	}

	public void start() {
		System.out.println(&quot;SERVER: Waiting for incomming connections...&quot;);
		System.out.println(&quot;DATE TIME IP:PORT   received_data&quot;);
		try {
			s = new DatagramSocket(this.port);
			while (true) {
				byte[] data = new byte[1412];
				DatagramPacket p = new DatagramPacket(data,
						data.length);
				s.receive(p);
				System.out.print(sdf.format(new Date()).toString() + &quot; &quot;);
				System.out.print(p.getSocketAddress() + &quot;   &quot;);
				System.out.println(new String(p.getData()));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}