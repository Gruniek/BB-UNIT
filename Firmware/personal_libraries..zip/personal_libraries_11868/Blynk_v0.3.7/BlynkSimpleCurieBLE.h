/**
 * @file       BlynkSimpleCurieBLE.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       May 2016
 * @brief
 *
 */

#ifndef BlynkSimpleCurieBLE_h
#define BlynkSimpleCurieBLE_h

#ifndef BLYNK_INFO_CONNECTION
#define BLYNK_INFO_CONNECTION &quot;CurieBLE&quot;
#endif

#define BLYNK_SEND_ATOMIC
#define BLYNK_SEND_CHUNK 20
//#define BLYNK_SEND_THROTTLE 20

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;utility/BlynkFifo2.h&gt;
#include &lt;CurieBLE.h&gt;

class BlynkTransportCurieBLE
{
public:
    BlynkTransportCurieBLE()
        : mConn (false)
    {}

    void begin(BLEPeripheral&amp; per) {
        instance = this;

        blePeripheral = &amp;per;
        // Add service and characteristic
        blePeripheral-&gt;setAdvertisedServiceUuid(bleService.uuid());
        blePeripheral-&gt;addAttribute(bleService);
        blePeripheral-&gt;addAttribute(rxChar);
        blePeripheral-&gt;addAttribute(txChar);

        unsigned char empty[0] = {};
        rxChar.setValue(empty, 0);
        txChar.setValue(empty, 0);

        // Assign event handlers for connected, disconnected to peripheral
        blePeripheral-&gt;setEventHandler(BLEDisconnected, blePeripheralDisconnectHandler);
        rxChar.setEventHandler(BLEWritten,    rxCharWritten);
        txChar.setEventHandler(BLESubscribed, txCharSubscribed);
    }

    bool connect() {
        mBuffRX.clear();
        return mConn = true;
    }

    void disconnect() {
        mConn = false;
    }

    bool connected() {
        return mConn;
    }

    size_t read(void* buf, size_t len) {
        uint32_t start = millis();
        while (millis() - start &lt; BLYNK_TIMEOUT_MS) {
            if (available() &lt; len) {
                blePeripheral-&gt;poll();
            } else {
                break;
            }
        }
        uint32_t key = interrupt_lock();
        size_t res = mBuffRX.get((uint8_t*)buf, len);
        interrupt_unlock(key);
        return res;
    }

    size_t write(const void* buf, size_t len) {
        txChar.setValue((uint8_t*)buf, len);
        return len;
    }

    size_t available() {
        uint32_t key = interrupt_lock();
        size_t rxSize = mBuffRX.size();
        interrupt_unlock(key);
        return rxSize;
    }

private:
    static BlynkTransportCurieBLE* instance;

    static
    void rxCharWritten(BLECentral&amp; central, BLECharacteristic&amp; ch) {
        if (!instance)
            return;
        uint32_t key = interrupt_lock();
        const uint8_t* data = ch.value();
        uint32_t len = ch.valueLength();
        //BLYNK_DBG_DUMP(&quot;&gt;&gt; &quot;, data, len);
        instance-&gt;mBuffRX.put(data, len);
        interrupt_unlock(key);
    }

    static
    void txCharSubscribed(BLECentral&amp; central, BLECharacteristic&amp; ch);

    static
    void blePeripheralDisconnectHandler(BLECentral&amp; central);

private:
    bool mConn;
    BLEPeripheral*    blePeripheral = NULL;
    BLEService        bleService = BLEService       (&quot;713D0000-503E-4C75-BA94-3148F18D941E&quot;);
    BLECharacteristic rxChar     = BLECharacteristic(&quot;713D0003-503E-4C75-BA94-3148F18D941E&quot;, BLEWrite | BLEWriteWithoutResponse, BLE_MAX_ATTR_DATA_LEN);
    BLECharacteristic txChar     = BLECharacteristic(&quot;713D0002-503E-4C75-BA94-3148F18D941E&quot;, BLERead  | BLENotify,               BLE_MAX_ATTR_DATA_LEN);

    BlynkFifo&lt;uint8_t, BLYNK_MAX_READBYTES*2&gt; mBuffRX;
};

class BlynkCurieBLE
    : public BlynkProtocol&lt;BlynkTransportCurieBLE&gt;
{
    typedef BlynkProtocol&lt;BlynkTransportCurieBLE&gt; Base;
public:
    BlynkCurieBLE(BlynkTransportCurieBLE&amp; transp)
        : Base(transp)
    {}

    void begin(const char* auth, BLEPeripheral&amp; per)
    {
        Base::begin(auth);
        state = DISCONNECTED;
        conn.begin(per);
    }
};

BlynkTransportCurieBLE* BlynkTransportCurieBLE::instance = NULL;

static BlynkTransportCurieBLE _blynkTransport;
BlynkCurieBLE Blynk(_blynkTransport);

inline
void BlynkTransportCurieBLE::txCharSubscribed(BLECentral&amp; central, BLECharacteristic&amp; ch) {
    Blynk.startSession();
}

inline
void BlynkTransportCurieBLE::blePeripheralDisconnectHandler(BLECentral&amp; central) {
    Blynk.disconnect();
}

#include &lt;BlynkWidgets.h&gt;

#endif
