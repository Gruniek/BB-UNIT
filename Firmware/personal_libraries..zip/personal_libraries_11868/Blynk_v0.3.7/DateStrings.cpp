/* DateStrings.cpp
 * Definitions for date strings for use with the Time library
 *
 * Updated for Arduino 1.5.7 18 July 2014
 *
 * No memory is consumed in the sketch if your code does not call any of the string methods
 * You can change the text of the strings, make sure the short strings are each exactly 3 characters 
 * the long strings can be any length up to the constant dt_MAX_STRING_LEN defined in TimeLib.h
 * 
 */

#if defined(__AVR__)
#include &lt;avr/pgmspace.h&gt;
#else
// for compatiblity with Arduino Due and Teensy 3.0 and maybe others?
#define PROGMEM
#define PGM_P  const char *
#define pgm_read_byte(addr) (*(const unsigned char *)(addr))
#define pgm_read_word(addr) (*(const unsigned char **)(addr))
#define strcpy_P(dest, src) strcpy((dest), (src))
#endif
#include &lt;string.h&gt; // for strcpy_P or strcpy
#include &quot;TimeLib.h&quot;
 
// the short strings for each day or month must be exactly dt_SHORT_STR_LEN
#define dt_SHORT_STR_LEN  3 // the length of short strings

static char buffer[dt_MAX_STRING_LEN+1];  // must be big enough for longest string and the terminating null

const char monthStr0[] PROGMEM = &quot;&quot;;
const char monthStr1[] PROGMEM = &quot;January&quot;;
const char monthStr2[] PROGMEM = &quot;February&quot;;
const char monthStr3[] PROGMEM = &quot;March&quot;;
const char monthStr4[] PROGMEM = &quot;April&quot;;
const char monthStr5[] PROGMEM = &quot;May&quot;;
const char monthStr6[] PROGMEM = &quot;June&quot;;
const char monthStr7[] PROGMEM = &quot;July&quot;;
const char monthStr8[] PROGMEM = &quot;August&quot;;
const char monthStr9[] PROGMEM = &quot;September&quot;;
const char monthStr10[] PROGMEM = &quot;October&quot;;
const char monthStr11[] PROGMEM = &quot;November&quot;;
const char monthStr12[] PROGMEM = &quot;December&quot;;

const PROGMEM char * const PROGMEM monthNames_P[] =
{
    monthStr0,monthStr1,monthStr2,monthStr3,monthStr4,monthStr5,monthStr6,
    monthStr7,monthStr8,monthStr9,monthStr10,monthStr11,monthStr12
};

const char monthShortNames_P[] PROGMEM = &quot;ErrJanFebMarAprMayJunJulAugSepOctNovDec&quot;;

const char dayStr0[] PROGMEM = &quot;Err&quot;;
const char dayStr1[] PROGMEM = &quot;Sunday&quot;;
const char dayStr2[] PROGMEM = &quot;Monday&quot;;
const char dayStr3[] PROGMEM = &quot;Tuesday&quot;;
const char dayStr4[] PROGMEM = &quot;Wednesday&quot;;
const char dayStr5[] PROGMEM = &quot;Thursday&quot;;
const char dayStr6[] PROGMEM = &quot;Friday&quot;;
const char dayStr7[] PROGMEM = &quot;Saturday&quot;;

const PROGMEM char * const PROGMEM dayNames_P[] =
{
   dayStr0,dayStr1,dayStr2,dayStr3,dayStr4,dayStr5,dayStr6,dayStr7
};

const char dayShortNames_P[] PROGMEM = &quot;ErrSunMonTueWedThuFriSat&quot;;

/* functions to return date strings */

char* monthStr(uint8_t month)
{
    strcpy_P(buffer, (PGM_P)pgm_read_word(&amp;(monthNames_P[month])));
    return buffer;
}

char* monthShortStr(uint8_t month)
{
   for (int i=0; i &lt; dt_SHORT_STR_LEN; i++)      
      buffer[i] = pgm_read_byte(&amp;(monthShortNames_P[i+ (month*dt_SHORT_STR_LEN)]));  
   buffer[dt_SHORT_STR_LEN] = 0;
   return buffer;
}

char* dayStr(uint8_t day) 
{
   strcpy_P(buffer, (PGM_P)pgm_read_word(&amp;(dayNames_P[day])));
   return buffer;
}

char* dayShortStr(uint8_t day) 
{
   uint8_t index = day*dt_SHORT_STR_LEN;
   for (int i=0; i &lt; dt_SHORT_STR_LEN; i++)      
      buffer[i] = pgm_read_byte(&amp;(dayShortNames_P[index + i]));  
   buffer[dt_SHORT_STR_LEN] = 0; 
   return buffer;
}
