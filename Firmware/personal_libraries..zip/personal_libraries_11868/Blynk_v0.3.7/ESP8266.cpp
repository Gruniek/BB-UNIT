/**
 * @file ESP8266.cpp
 * @brief The implementation of class ESP8266. 
 * @author Wu Pengfei&lt;pengfei.wu@itead.cc&gt; 
 * @date 2015.02
 * 
 * @par Copyright:
 * Copyright (c) 2015 ITEAD Intelligent Systems Co., Ltd. \n\n
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version. \n\n
 * THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include &quot;ESP8266_Lib.h&quot;
#include &lt;avr/pgmspace.h&gt;

ESP8266::ESP8266(Stream *uart)
    : m_puart(uart)
{
    m_onData = NULL;
    m_onDataPtr = NULL;
}

bool ESP8266::kick(void)
{
    return eAT();
}

bool ESP8266::restart(void)
{
    unsigned long start;
    if (eATRST()) {
        delay(2000);
        start = millis();
        while (millis() - start &lt; 3000) {
            if (eAT()) {
                delay(1500); /* Waiting for stable */
                return true;
            }
            delay(100);
        }
    }
    return false;
}

String ESP8266::getVersion(void)
{
    String version;
    eATGMR(version);
    return version;
}

bool ESP8266::setEcho(uint8_t mode)
{
    return eATE(mode);
}

bool ESP8266::restore(void)
{
    return eATRESTORE();
}
bool ESP8266::setUart(uint32_t baudrate,uint8_t pattern)
{
    return eATSETUART(baudrate,pattern);
}

bool ESP8266::deepSleep(uint32_t time)
{
    return eATGSLP(time);
}


bool ESP8266::setOprToStation(uint8_t pattern1,uint8_t pattern2)
{
    uint8_t mode;
    if (!qATCWMODE(&amp;mode,pattern1)) {
        return false;
    }
    if (mode == 1) {
        return true;
    } else {
        if (sATCWMODE(1,pattern2)){
            return true;
        } else {
            return false;
        }
    }
}
String ESP8266::getWifiModeList(void)
{   
     String list;
     eATCWMODE(list);
     return list;
}
bool ESP8266::setOprToSoftAP(uint8_t pattern1,uint8_t pattern2)
{
    uint8_t mode;
    if (!qATCWMODE(&amp;mode,pattern1)) {
        return false;
    }
    if (mode == 2) {
        return true;
    } else {
        if (sATCWMODE(2,pattern2) ){
            return true;
        } else {
            return false;
        }
    }
}

bool ESP8266::setOprToStationSoftAP(uint8_t pattern1,uint8_t pattern2)
{
    uint8_t mode;
    if (!qATCWMODE(&amp;mode,pattern1)) {
        return false;
    }
    if (mode == 3) {
        return true;
    } else {
        if (sATCWMODE(3,pattern2) ){
            return true;
        } else {
            return false;
        }
    }
}

uint8_t ESP8266::getOprMode(uint8_t pattern1)
{
	uint8_t mode;
	if (!qATCWMODE(&amp;mode,pattern1)) {
        return 0;
    } else {
		return mode;
    }
}

String ESP8266::getNowConecAp(uint8_t pattern)
{   
     String ssid;
     qATCWJAP(ssid,pattern);
     return ssid;
}


String ESP8266::getAPList(void)
{
    String list;
    eATCWLAP(list);
    return list;
}

bool ESP8266::joinAP(String ssid, String pwd,uint8_t pattern)
{
    return sATCWJAP(ssid, pwd,pattern);
}

bool ESP8266::leaveAP(void)
{
    return eATCWQAP();
}

String ESP8266::getSoftAPParam(uint8_t pattern)
{   
     String list;
     qATCWSAP(list,pattern);
     return list;
}



bool ESP8266::setSoftAPParam(String ssid, String pwd, uint8_t chl, uint8_t ecn,uint8_t pattern)
{
    return sATCWSAP(ssid, pwd, chl, ecn,pattern);
}

String ESP8266::getJoinedDeviceIP(void)
{
    String list;
    eATCWLIF(list);
    return list;
}

String ESP8266::getDHCP(uint8_t pattern)
{   
     String dhcp;
     qATCWDHCP(dhcp,pattern);
     return dhcp;
}
bool ESP8266::setDHCP(uint8_t mode, uint8_t en, uint8_t pattern)
{
    return sATCWDHCP(mode, en, pattern);
}

bool ESP8266::setAutoConnect(uint8_t en)
{
    return eATCWAUTOCONN(en);
}
String ESP8266::getStationMac(uint8_t pattern)
{
    String mac;
    qATCIPSTAMAC(mac,pattern);
    return mac;
}


bool ESP8266::setStationMac(String mac,uint8_t pattern)
{
   return eATCIPSTAMAC(mac,pattern);
}

String ESP8266::getStationIp(uint8_t pattern)
{
    String ip;
    qATCIPSTAIP(ip,pattern);
    return ip;
}

bool ESP8266::setStationIp(String ip,String gateway,String netmask,uint8_t pattern)
{
   return eATCIPSTAIP(ip,gateway,netmask,pattern);
}

String ESP8266::getAPIp(uint8_t pattern)
{
    String ip;
    qATCIPAP(ip,pattern);
    return ip;
}

bool ESP8266::setAPIp(String ip,uint8_t pattern)
{
   return eATCIPAP(ip,pattern);
}

bool ESP8266::startSmartConfig(uint8_t type)
{
    return eCWSTARTSMART(type);
}

bool ESP8266::stopSmartConfig(void)
{
    return eCWSTOPSMART();
}




String ESP8266::getIPStatus(void)
{
    String list;
    eATCIPSTATUS(list);
    return list;
}

String ESP8266::getLocalIP(void)
{
    String list;
    eATCIFSR(list);
    return list;
}

bool ESP8266::enableMUX(void)
{
    return sATCIPMUX(1);
}

bool ESP8266::disableMUX(void)
{
    return sATCIPMUX(0);
}

bool ESP8266::createTCP(String addr, uint32_t port)
{
    return sATCIPSTARTSingle(&quot;TCP&quot;, addr, port);
}

bool ESP8266::releaseTCP(void)
{
    return eATCIPCLOSESingle();
}

bool ESP8266::registerUDP(String addr, uint32_t port)
{
    return sATCIPSTARTSingle(&quot;UDP&quot;, addr, port);
}

bool ESP8266::unregisterUDP(void)
{
    return eATCIPCLOSESingle();
}

bool ESP8266::createTCP(uint8_t mux_id, String addr, uint32_t port)
{
    return sATCIPSTARTMultiple(mux_id, &quot;TCP&quot;, addr, port);
}

bool ESP8266::releaseTCP(uint8_t mux_id)
{
    return sATCIPCLOSEMulitple(mux_id);
}

bool ESP8266::registerUDP(uint8_t mux_id, String addr, uint32_t port)
{
    return sATCIPSTARTMultiple(mux_id, &quot;UDP&quot;, addr, port);
}

bool ESP8266::unregisterUDP(uint8_t mux_id)
{
    return sATCIPCLOSEMulitple(mux_id);
}

bool ESP8266::setTCPServerTimeout(uint32_t timeout)
{
    return sATCIPSTO(timeout);
}

bool ESP8266::startTCPServer(uint32_t port)
{
    if (sATCIPSERVER(1, port)) {
        return true;
    }
    return false;
}

bool ESP8266::stopTCPServer(void)
{
    sATCIPSERVER(0);
    restart();
    return false;
}

bool ESP8266::setCIPMODE(uint8_t mode)
{
    return sATCIPMODE(mode);
}

bool ESP8266::saveTransLink (uint8_t mode,String ip,uint32_t port)
{
    return eATSAVETRANSLINK(mode,ip,port);
}

bool ESP8266::setPing(String ip)
{
    return eATPING(ip);
}




bool ESP8266::startServer(uint32_t port)
{
    return startTCPServer(port);
}

bool ESP8266::stopServer(void)
{
    return stopTCPServer();
}

bool ESP8266::send(const uint8_t *buffer, uint32_t len)
{
    return sATCIPSENDSingle(buffer, len);
}

bool ESP8266::sendFromFlash(uint8_t mux_id, const uint8_t *buffer, uint32_t len)
{
    return sATCIPSENDMultipleFromFlash(mux_id, buffer, len);
}

bool ESP8266::sendFromFlash(const uint8_t *buffer, uint32_t len)
{
    return sATCIPSENDSingleFromFlash(buffer, len);
}

bool ESP8266::send(uint8_t mux_id, const uint8_t *buffer, uint32_t len)
{
    return sATCIPSENDMultiple(mux_id, buffer, len);
}

void ESP8266::run()
{
    rx_empty();
}

/*----------------------------------------------------------------------------*/
/* +IPD,&lt;id&gt;,&lt;len&gt;:&lt;data&gt; */
/* +IPD,&lt;len&gt;:&lt;data&gt; */

uint32_t ESP8266::checkIPD(String&amp; data)
{
    //Serial.print(&quot;### check: &quot;);
    //Serial.println(data);

    int32_t index_PIPDcomma = -1;
    int32_t index_colon = -1; /* : */
    int32_t index_comma = -1; /* , */
    int32_t len = -1;
    int8_t id = -1;
    { // Just for easier diffing
        index_PIPDcomma = data.indexOf(&quot;+IPD,&quot;);
        if (index_PIPDcomma != -1) {
            index_colon = data.indexOf(':', index_PIPDcomma + 5);
            if (index_colon != -1) {
                index_comma = data.indexOf(',', index_PIPDcomma + 5);
                /* +IPD,id,len:data */
                if (index_comma != -1 &amp;&amp; index_comma &lt; index_colon) { 
                    id = data.substring(index_PIPDcomma + 5, index_comma).toInt();
                    if (id &lt; 0 || id &gt; 4) {
                        return 0;
                    }
                    len = data.substring(index_comma + 1, index_colon).toInt();
                    if (len &lt;= 0) {
                        return 0;
                    }
                } else { /* +IPD,len:data */
                    len = data.substring(index_PIPDcomma + 5, index_colon).toInt();
                    if (len &lt;= 0) {
                        return 0;
                    }
                }
                if (m_onData) {
                    m_onData(id, len, m_onDataPtr);
                }
                return len;
            }
        }
    }
    return 0;
}

void ESP8266::rx_empty(void) 
{
    String data;
    char a;
    unsigned long start = millis();
    while (millis() - start &lt; 10) {
        if (m_puart-&gt;available()) {
            a = m_puart-&gt;read();
            if(a == '\0') continue;
            data += a;
            if (checkIPD(data)) {
                data = &quot;&quot;;
            }
            start = millis();
        }
    }
}

String ESP8266::recvString(String target, uint32_t timeout)
{
    String data;
    char a;
    unsigned long start = millis();
    while (millis() - start &lt; timeout) {
        while(m_puart-&gt;available() &gt; 0) {
            a = m_puart-&gt;read();
            if(a == '\0') continue;
            data += a;
            if (data.indexOf(target) != -1) {
                return data;
            } else if (checkIPD(data)) {
                data = &quot;&quot;;
            }
        }
    }
    
    return data;
}

String ESP8266::recvString(String target1, String target2, uint32_t timeout)
{
    String data;
    char a;
    unsigned long start = millis();
    while (millis() - start &lt; timeout) {
        while(m_puart-&gt;available() &gt; 0) {
            a = m_puart-&gt;read();
            if(a == '\0') continue;
            data += a;
            if (data.indexOf(target1) != -1) {
                return data;
            } else if (data.indexOf(target2) != -1) {
                return data;
            } else if (checkIPD(data)) {
                data = &quot;&quot;;
            }
        }
    }
    return data;
}

String ESP8266::recvString(String target1, String target2, String target3, uint32_t timeout)
{
    String data;
    char a;
    unsigned long start = millis();
    while (millis() - start &lt; timeout) {
        while(m_puart-&gt;available() &gt; 0) {
            a = m_puart-&gt;read();
            if(a == '\0') continue;
            data += a;
            
            if (data.indexOf(target1) != -1) {
                return data;
            } else if (data.indexOf(target2) != -1) {
                return data;
            } else if (data.indexOf(target3) != -1) {
                return data;
            } else if (checkIPD(data)) {
                data = &quot;&quot;;
            }
        }
    }
    return data;
}

bool ESP8266::recvFind(String target, uint32_t timeout)
{
    String data_tmp;
    data_tmp = recvString(target, timeout);
    if (data_tmp.indexOf(target) != -1) {
        return true;
    }
    return false;
}

bool ESP8266::recvFindAndFilter(String target, String begin, String end, String &amp;data, uint32_t timeout)
{
    String data_tmp;
    data_tmp = recvString(target, timeout);
    if (data_tmp.indexOf(target) != -1) {
        int32_t index1 = data_tmp.indexOf(begin);
        int32_t index2 = data_tmp.indexOf(end);
        if (index1 != -1 &amp;&amp; index2 != -1) {
            index1 += begin.length();
            data = data_tmp.substring(index1, index2);
            return true;
        }
    }
    data = data_tmp;
    return false;
}

bool ESP8266::eAT(void)
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT&quot;));
    return recvFind(&quot;OK&quot;);
}

bool ESP8266::eATRST(void) 
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+RST&quot;));
    return recvFind(&quot;OK&quot;);
}

bool ESP8266::eATGMR(String &amp;version)
{
    rx_empty();
    delay(3000);
    m_puart-&gt;println(F(&quot;AT+GMR&quot;));
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, version,10000); 
}

bool ESP8266::eATGSLP(uint32_t time)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+GSLP=&quot;));
    m_puart-&gt;println(time);
    return recvFind(&quot;OK&quot;);
}


bool ESP8266::eATE(uint8_t mode)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;ATE&quot;));
    m_puart-&gt;println(mode);
    return recvFind(&quot;OK&quot;);
}

bool ESP8266::eATRESTORE(void)
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+RESTORE&quot;));
    return recvFind(&quot;OK&quot;);
}


bool ESP8266::eATSETUART(uint32_t baudrate,uint8_t pattern)
{
    rx_empty();
    if(pattern&gt;3||pattern&lt;1){
        return false;
        }
    switch(pattern){
        case 1:
            m_puart-&gt;print(F(&quot;AT+UART=&quot;));
            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+UART_CUR=&quot;));
            break;
        case 3:
             m_puart-&gt;print(F(&quot;AT+UART_DEF=&quot;));
             break;    
    }
    m_puart-&gt;print(baudrate);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;print(8);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;print(1);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;print(0);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;println(0);
    if(recvFind(&quot;OK&quot;,5000)){
    return true;
    }
    else{
    return false;
    }
 
}


bool ESP8266::qATCWMODE(uint8_t *mode,uint8_t pattern) 
{
    String str_mode;
    bool ret;
    if (!mode||!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern)
    {
        case 1 :
            m_puart-&gt;println(F(&quot;AT+CWMODE_DEF?&quot;));
            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CWMODE_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CWMODE?&quot;));
    }
    ret = recvFindAndFilter(&quot;OK&quot;, &quot;:&quot;, &quot;\r\n\r\nOK&quot;, str_mode); 
    if (ret) {
        *mode = (uint8_t)str_mode.toInt();       
        return true;
    } else {
        return false;
    }
}
bool ESP8266::eATCWMODE(String &amp;list) 
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CWMODE=?&quot;));
    return recvFindAndFilter(&quot;OK&quot;, &quot;+CWMODE:(&quot;, &quot;)\r\n\r\nOK&quot;, list);
}

bool ESP8266::sATCWMODE(uint8_t mode,uint8_t pattern)
{
    if(!pattern){
        return false;
        }
    String data;
    rx_empty();
    switch(pattern)
    {
        case 1 :
            m_puart-&gt;print(F(&quot;AT+CWMODE_DEF=&quot;));
            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CWMODE_CUR=&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CWMODE=&quot;));
    }
    m_puart-&gt;println(mode);
    data = recvString(&quot;OK&quot;, &quot;no change&quot;);

    if (data.indexOf(&quot;OK&quot;) != -1 || data.indexOf(&quot;no change&quot;) != -1) {
        return true;
    }
    return false;
}


bool ESP8266::qATCWJAP(String &amp;ssid,uint8_t pattern) 
{

    bool ret;
    if (!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern)
    {
        case 1 :
            m_puart-&gt;println(F(&quot;AT+CWJAP_DEF?&quot;));
            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CWJAP_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CWJAP?&quot;));
    }
    ssid = recvString(&quot;OK&quot;, &quot;No AP&quot;);
    if (ssid.indexOf(&quot;OK&quot;) != -1 || ssid.indexOf(&quot;No AP&quot;) != -1) {
        return true;
    }
    return false;
 
}

bool ESP8266::sATCWJAP(String ssid, String pwd,uint8_t pattern)
{
    String data;
    if (!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern)
    {
        case 1 :
            m_puart-&gt;print(F(&quot;AT+CWJAP_DEF=\&quot;&quot;));

            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CWJAP_CUR=\&quot;&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CWJAP=\&quot;&quot;));
    }
    
    m_puart-&gt;print(ssid);
    m_puart-&gt;print(F(&quot;\&quot;,\&quot;&quot;));
    m_puart-&gt;print(pwd);
    m_puart-&gt;println(F(&quot;\&quot;&quot;));
    
    data = recvString(&quot;OK&quot;, &quot;FAIL&quot;, 10000);
    if (data.indexOf(&quot;OK&quot;) != -1) {
        return true;
    }
    return false;
}

bool ESP8266::eATCWLAP(String &amp;list) 
{
    String data;
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CWLAP&quot;));
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, list, 15000);
}




bool ESP8266::eATCWQAP(void)
{
    String data;
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CWQAP&quot;));
    return recvFind(&quot;OK&quot;);
}


bool ESP8266::qATCWSAP(String &amp;List,uint8_t pattern) 
{
    if (!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern)
    {
        case 1 :
            m_puart-&gt;println(F(&quot;AT+CWSAP_DEF?&quot;));

            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CWSAP_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CWSAP?&quot;));
    }
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, List,10000);

}

bool ESP8266::sATCWSAP(String ssid, String pwd, uint8_t chl, uint8_t ecn,uint8_t pattern)
{
    String data;
    if (!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern){
         case 1 :
            m_puart-&gt;print(F(&quot;AT+CWSAP_DEF=\&quot;&quot;));

            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CWSAP_CUR=\&quot;&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CWSAP=\&quot;&quot;));

    }
    m_puart-&gt;print(ssid);
    m_puart-&gt;print(F(&quot;\&quot;,\&quot;&quot;));
    m_puart-&gt;print(pwd);
    m_puart-&gt;print(F(&quot;\&quot;,&quot;));
    m_puart-&gt;print(chl);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;println(ecn);
    
    data = recvString(&quot;OK&quot;, &quot;ERROR&quot;, 5000);
    if (data.indexOf(&quot;OK&quot;) != -1) {
        return true;
    }
    return false;
}

bool ESP8266::eATCWLIF(String &amp;list)
{
    String data;
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CWLIF&quot;));
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, list);
}

bool ESP8266::qATCWDHCP(String &amp;List,uint8_t pattern) 
{
    if (!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern)
    {
        case 1 :
            m_puart-&gt;println(F(&quot;AT+CWDHCP_DEF?&quot;));
            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CWDHCP_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CWDHCP?&quot;));
    }

    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\nOK&quot;, List,10000);

}


bool ESP8266::sATCWDHCP(uint8_t mode, uint8_t en, uint8_t pattern)
{
    String data;
    if (!pattern) {
        return false;
    }
    rx_empty();
    switch(pattern){
         case 1 :
            m_puart-&gt;print(F(&quot;AT+CWDHCP_DEF=&quot;));

            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CWDHCP_CUR=&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CWDHCP=&quot;));

    }
    m_puart-&gt;print(mode);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;println(en);    
    data = recvString(&quot;OK&quot;, &quot;ERROR&quot;, 2000);

    if (data.indexOf(&quot;OK&quot;) != -1) {
        return true;
    }
    return false;
}


bool ESP8266::eATCWAUTOCONN(uint8_t en)
{

    rx_empty();
    if(en&gt;1||en&lt;0){
        return false;
    }
    m_puart-&gt;print(F(&quot;AT+CWAUTOCONN=&quot;));
    m_puart-&gt;println(en);
    return recvFind(&quot;OK&quot;);

}

bool ESP8266::qATCIPSTAMAC(String &amp;mac,uint8_t pattern)
{

    rx_empty();
    if (!pattern) {
        return false;
    }
    switch(pattern){
         case 1 :
            m_puart-&gt;println(F(&quot;AT+CIPSTAMAC_DEF?&quot;));

            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CIPSTAMAC_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CIPSTAMAC?&quot;));

    }
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, mac,2000);

}



bool ESP8266::eATCIPSTAMAC(String mac,uint8_t pattern)
{

    rx_empty();
    if (!pattern) {
        return false;
    }
    switch(pattern){
         case 1 :
            m_puart-&gt;print(F(&quot;AT+CIPSTAMAC_DEF=&quot;));

            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CIPSTAMAC_CUR=&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CIPSTAMAC=&quot;));

    }
    m_puart-&gt;print(F(&quot;\&quot;&quot;));
    m_puart-&gt;print(mac);
    m_puart-&gt;println(F(&quot;\&quot;&quot;));
    return recvFind(&quot;OK&quot;);

}

bool ESP8266::qATCIPSTAIP(String &amp;ip,uint8_t pattern)
{

    rx_empty();
    if (!pattern) {
        return false;
    }
    switch(pattern){
         case 1 :
            m_puart-&gt;println(F(&quot;AT+CIPSTA_DEF?&quot;));

            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CIPSTA_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CIPSTA?&quot;));

    }
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, ip,2000);

}

bool ESP8266::eATCIPSTAIP(String ip,String gateway,String netmask,uint8_t pattern)
{

    rx_empty();
    if (!pattern) {
        return false;
    }
    switch(pattern){
         case 1 :
            m_puart-&gt;print(F(&quot;AT+CIPSTA_DEF=&quot;));

            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CIPSTA_CUR=&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CIPSTA=&quot;));

    }
    m_puart-&gt;print(F(&quot;\&quot;&quot;));
    m_puart-&gt;print(ip);
    m_puart-&gt;print(F(&quot;\&quot;,\&quot;&quot;));
    m_puart-&gt;print(gateway);
    m_puart-&gt;print(F(&quot;\&quot;,\&quot;&quot;));
    m_puart-&gt;print(netmask);
    m_puart-&gt;println(F(&quot;\&quot;&quot;));
    return recvFind(&quot;OK&quot;);

}


bool ESP8266::qATCIPAP(String &amp;ip,uint8_t pattern)
{

    rx_empty();
    if (!pattern) {
        return false;
    }
    switch(pattern){
         case 1 :
            m_puart-&gt;println(F(&quot;AT+CIPAP_DEF?&quot;));

            break;
        case 2:
            m_puart-&gt;println(F(&quot;AT+CIPAP_CUR?&quot;));
            break;
        default:
            m_puart-&gt;println(F(&quot;AT+CIPAP?&quot;));

    }
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, ip,2000);

}


bool ESP8266::eATCIPAP(String ip,uint8_t pattern)
{

    rx_empty();
    if (!pattern) {
        return false;
    }
    switch(pattern){
         case 1 :
            m_puart-&gt;print(F(&quot;AT+CIPAP_DEF=&quot;));

            break;
        case 2:
            m_puart-&gt;print(F(&quot;AT+CIPAP_CUR=&quot;));
            break;
        default:
            m_puart-&gt;print(F(&quot;AT+CIPAP=&quot;));

    }
    m_puart-&gt;print(F(&quot;\&quot;&quot;));
    m_puart-&gt;print(ip);
    m_puart-&gt;println(F(&quot;\&quot;&quot;));
    return recvFind(&quot;OK&quot;);

}


bool ESP8266::eCWSTARTSMART(uint8_t type)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CWSTARTSMART=&quot;));
    m_puart-&gt;println(type);
    return recvFind(&quot;OK&quot;);
}

bool ESP8266::eCWSTOPSMART(void)
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CWSTOPSMART&quot;));
    return recvFind(&quot;OK&quot;);
}

bool ESP8266::eATCIPSTATUS(String &amp;list)
{
    String data;
    delay(100);
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CIPSTATUS&quot;));
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, list);
}
bool ESP8266::sATCIPSTARTSingle(String type, String addr, uint32_t port)
{
    String data;
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSTART=\&quot;&quot;));
    m_puart-&gt;print(type);
    m_puart-&gt;print(F(&quot;\&quot;,\&quot;&quot;));
    m_puart-&gt;print(addr);
    m_puart-&gt;print(F(&quot;\&quot;,&quot;));
    m_puart-&gt;println(port);
    
    data = recvString(&quot;OK&quot;, &quot;ERROR&quot;, &quot;ALREADY CONNECT&quot;, 10000);
    if (data.indexOf(&quot;OK&quot;) != -1 || data.indexOf(&quot;ALREADY CONNECT&quot;) != -1) {
        return true;
    }
    return false;
}
bool ESP8266::sATCIPSTARTMultiple(uint8_t mux_id, String type, String addr, uint32_t port)
{
    String data;
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSTART=&quot;));
    m_puart-&gt;print(mux_id);
    m_puart-&gt;print(F(&quot;,\&quot;&quot;));
    m_puart-&gt;print(type);
    m_puart-&gt;print(F(&quot;\&quot;,\&quot;&quot;));
    m_puart-&gt;print(addr);
    m_puart-&gt;print(F(&quot;\&quot;,&quot;));
    m_puart-&gt;println(port);
    
    data = recvString(&quot;OK&quot;, &quot;ERROR&quot;, &quot;ALREADY CONNECT&quot;, 10000);
    if (data.indexOf(&quot;OK&quot;) != -1 || data.indexOf(&quot;ALREADY CONNECT&quot;) != -1) {
        return true;
    }
    return false;
}
bool ESP8266::sATCIPSENDSingle(const uint8_t *buffer, uint32_t len)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSEND=&quot;));
    m_puart-&gt;println(len);
    if (recvFind(&quot;&gt;&quot;, 5000)) {
        rx_empty();
        for (uint32_t i = 0; i &lt; len; i++) {
            m_puart-&gt;write(buffer[i]);
        }
        return recvFind(&quot;SEND OK&quot;, 10000);
    }
    return false;
}
bool ESP8266::sATCIPSENDMultiple(uint8_t mux_id, const uint8_t *buffer, uint32_t len)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSEND=&quot;));
    m_puart-&gt;print(mux_id);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;println(len);
    if (recvFind(&quot;&gt;&quot;, 5000)) {
        rx_empty();
        for (uint32_t i = 0; i &lt; len; i++) {
            m_puart-&gt;write(buffer[i]);
        }
        return recvFind(&quot;SEND OK&quot;, 10000);
    }
    return false;
}
bool ESP8266::sATCIPSENDSingleFromFlash(const uint8_t *buffer, uint32_t len)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSEND=&quot;));
    m_puart-&gt;println(len);
    if (recvFind(&quot;&gt;&quot;, 5000)) {
        rx_empty();
        for (uint32_t i = 0; i &lt; len; i++) {
            m_puart-&gt;write((char) pgm_read_byte(&amp;buffer[i]));
        }
        return recvFind(&quot;SEND OK&quot;, 10000);
    }
    return false;
}
bool ESP8266::sATCIPSENDMultipleFromFlash(uint8_t mux_id, const uint8_t *buffer, uint32_t len)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSEND=&quot;));
    m_puart-&gt;print(mux_id);
    m_puart-&gt;print(F(&quot;,&quot;));
    m_puart-&gt;println(len);
    if (recvFind(&quot;&gt;&quot;, 5000)) {
        rx_empty();
        for (uint32_t i = 0; i &lt; len; i++) {
            m_puart-&gt;write((char) pgm_read_byte(&amp;buffer[i]));
        }
        return recvFind(&quot;SEND OK&quot;, 10000);
    }
    return false;
}
bool ESP8266::sATCIPCLOSEMulitple(uint8_t mux_id)
{
    String data;
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPCLOSE=&quot;));
    m_puart-&gt;println(mux_id);
    
    data = recvString(&quot;OK&quot;, &quot;link is not&quot;, 5000);
    if (data.indexOf(&quot;OK&quot;) != -1 || data.indexOf(&quot;link is not&quot;) != -1) {
        return true;
    }
    return false;
}
bool ESP8266::eATCIPCLOSESingle(void)
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CIPCLOSE&quot;));
    return recvFind(&quot;OK&quot;, 5000);
}
bool ESP8266::eATCIFSR(String &amp;list)
{
    rx_empty();
    m_puart-&gt;println(F(&quot;AT+CIFSR&quot;));
    return recvFindAndFilter(&quot;OK&quot;, &quot;\r\r\n&quot;, &quot;\r\n\r\nOK&quot;, list);
}
bool ESP8266::sATCIPMUX(uint8_t mode)
{
    String data;
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPMUX=&quot;));
    m_puart-&gt;println(mode);
    
    data = recvString(&quot;OK&quot;, &quot;Link is builded&quot;);
    if (data.indexOf(&quot;OK&quot;) != -1) {
        return true;
    }
    return false;
}
bool ESP8266::sATCIPSERVER(uint8_t mode, uint32_t port)
{
    String data;
    if (mode) {
        rx_empty();
        m_puart-&gt;print(F(&quot;AT+CIPSERVER=1,&quot;));
        m_puart-&gt;println(port);
        
        data = recvString(&quot;OK&quot;, &quot;no change&quot;);
        if (data.indexOf(&quot;OK&quot;) != -1 || data.indexOf(&quot;no change&quot;) != -1) {
            return true;
        }
        return false;
    } else {
        rx_empty();
        m_puart-&gt;println(F(&quot;AT+CIPSERVER=0&quot;));
        return recvFind(&quot;\r\r\n&quot;);
    }
}


bool ESP8266::sATCIPMODE(uint8_t mode)
{
    String data;
    if(mode&gt;1||mode&lt;0){
        return false;
        }
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPMODE=&quot;));
    m_puart-&gt;println(mode);
    
    data = recvString(&quot;OK&quot;, &quot;Link is builded&quot;,2000);
    if (data.indexOf(&quot;OK&quot;) != -1 ) {
        return true;
    }
    return false;
}




bool ESP8266::eATSAVETRANSLINK(uint8_t mode,String ip,uint32_t port)
{

    String data;
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+SAVETRANSLINK=&quot;));
    m_puart-&gt;print(mode);
    m_puart-&gt;print(F(&quot;,\&quot;&quot;));
    m_puart-&gt;print(ip);
    m_puart-&gt;print(F(&quot;\&quot;,&quot;));
    m_puart-&gt;println(port);
    data = recvString(&quot;OK&quot;, &quot;ERROR&quot;,2000);
    if (data.indexOf(&quot;OK&quot;) != -1 ) {
        return true;
    }
    return false;
}



bool ESP8266::eATPING(String ip)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+PING=&quot;));
    m_puart-&gt;print(F(&quot;\&quot;&quot;));
    m_puart-&gt;print(ip);
    m_puart-&gt;println(F(&quot;\&quot;&quot;));
    return recvFind(&quot;OK&quot;,2000);
}



bool ESP8266::sATCIPSTO(uint32_t timeout)
{
    rx_empty();
    m_puart-&gt;print(F(&quot;AT+CIPSTO=&quot;));
    m_puart-&gt;println(timeout);
    return recvFind(&quot;OK&quot;);
}

