/**
 * @file       BlynkSimpleEsp8266_SSL.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2016
 * @brief
 *
 */

#ifndef BlynkSimpleEsp8266_SSL_h
#define BlynkSimpleEsp8266_SSL_h

#ifndef ESP8266
#error This code is intended to run on the ESP8266 platform! Please check your Tools-&gt;Board setting.
#endif

#ifndef BLYNK_INFO_DEVICE
#define BLYNK_INFO_DEVICE  &quot;ESP8266&quot;
#endif

#define BLYNK_DEFAULT_FINGERPRINT &quot;FD C0 7D 8D 47 97 F7 E3 07 05 D3 4E E3 BB 8E 3D C0 EA BE 1C&quot;

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;Adapters/BlynkArduinoClient.h&gt;
#include &lt;ESP8266WiFi.h&gt;
#include &lt;WiFiClientSecure.h&gt;

template &lt;typename Client&gt;
class BlynkArduinoClientSecure
	: public BlynkArduinoClientGen&lt;Client&gt;
{
public:
	BlynkArduinoClientSecure(Client&amp; client)
		: BlynkArduinoClientGen&lt;Client&gt;(client)
		, fingerprint(NULL)
	{}

	void setFingerprint(const char* fp) { fingerprint = fp; }

    bool connect() {
        if (BlynkArduinoClientGen&lt;Client&gt;::connect()) {
          // TODO: Enable when https://github.com/esp8266/Arduino/issues/1285 is closed
		  /*if (fingerprint &amp;&amp; !this-&gt;client.verify(fingerprint, this-&gt;domain)) {
			  BLYNK_LOG1(BLYNK_F(&quot;Certificate doesn't match&quot;));
			  return false;
		  } else {
			  BLYNK_LOG1(BLYNK_F(&quot;Certificate OK&quot;));
		  }*/
		  return true;
        }
        return false;
    }

private:
    const char* fingerprint;
};

template &lt;typename Transport&gt;
class BlynkWifi
    : public BlynkProtocol&lt;Transport&gt;
{
    typedef BlynkProtocol&lt;Transport&gt; Base;
public:
    BlynkWifi(Transport&amp; transp)
        : Base(transp)
    {}

    void connectWiFi(const char* ssid, const char* pass)
    {
        BLYNK_LOG2(BLYNK_F(&quot;Connecting to &quot;), ssid);
        WiFi.mode(WIFI_STA);
        if (pass &amp;&amp; strlen(pass)) {
        	WiFi.begin(ssid, pass);
        } else {
        	WiFi.begin(ssid);
        }
        while (WiFi.status() != WL_CONNECTED) {
            ::delay(500);
        }
        BLYNK_LOG1(BLYNK_F(&quot;Connected to WiFi&quot;));

        IPAddress myip = WiFi.localIP();
        BLYNK_LOG_IP(&quot;IP: &quot;, myip);
    }

    void config(const char* auth,
                const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT_SSL,
				const char* fingerprint = BLYNK_DEFAULT_FINGERPRINT)
    {
        Base::begin(auth);
        this-&gt;conn.begin(domain, port);
        this-&gt;conn.setFingerprint(fingerprint);
    }

    void config(const char* auth,
            	IPAddress   ip,
                uint16_t    port = BLYNK_DEFAULT_PORT_SSL,
				const char* fingerprint = BLYNK_DEFAULT_FINGERPRINT)
    {
        Base::begin(auth);
        this-&gt;conn.begin(ip, port);
        this-&gt;conn.setFingerprint(fingerprint);
    }

    void begin(const char* auth,
               const char* ssid,
               const char* pass,
               const char* domain = BLYNK_DEFAULT_DOMAIN,
               uint16_t    port   = BLYNK_DEFAULT_PORT_SSL,
			   const char* fingerprint = BLYNK_DEFAULT_FINGERPRINT)
    {
        connectWiFi(ssid, pass);
        config(auth, domain, port, fingerprint);
    }

    void begin(const char* auth,
               const char* ssid,
               const char* pass,
               IPAddress   ip,
               uint16_t    port   = BLYNK_DEFAULT_PORT_SSL,
			   const char* fingerprint = BLYNK_DEFAULT_FINGERPRINT)
    {
        connectWiFi(ssid, pass);
        config(auth, ip, port, fingerprint);
    }

};

static WiFiClientSecure _blynkWifiClient;
static BlynkArduinoClientSecure&lt;WiFiClientSecure&gt; _blynkTransport(_blynkWifiClient);
BlynkWifi&lt;BlynkArduinoClientSecure&lt;WiFiClientSecure&gt; &gt; Blynk(_blynkTransport);

#include &lt;BlynkWidgets.h&gt;

#endif
