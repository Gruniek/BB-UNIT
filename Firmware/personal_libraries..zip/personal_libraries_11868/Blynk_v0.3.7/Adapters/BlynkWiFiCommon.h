/**
 * @file       BlynkWiFiCommon.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2015
 * @brief
 *
 */

#ifndef BlynkWiFiCommon_h
#define BlynkWiFiCommon_h

#ifndef BLYNK_INFO_CONNECTION
#define BLYNK_INFO_CONNECTION &quot;WiFi&quot;
#endif

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;Adapters/BlynkArduinoClient.h&gt;

class BlynkWifiCommon
    : public BlynkProtocol&lt;BlynkArduinoClient&gt;
{
    typedef BlynkProtocol&lt;BlynkArduinoClient&gt; Base;
public:
    BlynkWifiCommon(BlynkArduinoClient&amp; transp)
        : Base(transp)
    {}

    void connectWiFi(const char* ssid, const char* pass)
    {
        int status = WL_IDLE_STATUS;
        // check for the presence of the shield:
        if (WiFi.status() == WL_NO_SHIELD) {
            BLYNK_FATAL(&quot;WiFi shield not present&quot;);
        }

        // attempt to connect to Wifi network:
        while (true) {
            BLYNK_LOG2(BLYNK_F(&quot;Connecting to &quot;), ssid);
            if (pass &amp;&amp; strlen(pass)) {
                status = WiFi.begin((char*)ssid, (char*)pass);
            } else {
                status = WiFi.begin((char*)ssid);
            }
            if (status == WL_CONNECTED) {
                break;
            } else {
                ::delay(5000);
            }
        }

        IPAddress myip = WiFi.localIP();
        BLYNK_LOG_IP(&quot;IP: &quot;, myip);
    }

    void config(const char* auth,
            	const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
    	Base::begin(auth);
    	this-&gt;conn.begin(domain, port);
    }

    void config(const char* auth,
            	IPAddress   ip,
                uint16_t    port = BLYNK_DEFAULT_PORT)
    {
    	Base::begin(auth);
    	this-&gt;conn.begin(ip, port);
    }

    void begin(const char* auth,
               const char* ssid,
               const char* pass,
               const char* domain = BLYNK_DEFAULT_DOMAIN,
               uint16_t port      = BLYNK_DEFAULT_PORT)
    {
        connectWiFi(ssid, pass);
    	config(auth, domain, port);
    }

    void begin(const char* auth,
               const char* ssid,
               const char* pass,
               IPAddress   ip,
               uint16_t    port = BLYNK_DEFAULT_PORT)
    {
        connectWiFi(ssid, pass);
    	config(auth, ip, port);
    }

};

#endif
