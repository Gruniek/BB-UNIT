/**
 * @file       BlynkCC3000.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Mar 2015
 * @brief
 *
 */

#ifndef BlynkCC3000_h
#define BlynkCC3000_h

#define BLYNK_INFO_CONNECTION &quot;CC3000&quot;

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;Adafruit_CC3000.h&gt;

class BlynkTransportCC3000
{
public:
    BlynkTransportCC3000(Adafruit_CC3000&amp; cc3000)
        : cc3000(cc3000), addr(0), port(0)
    {}

    void begin(uint32_t a, uint16_t p) {
        port = p;
        addr = a;
    }

    bool connect() {
        uint8_t* a = (uint8_t*)&amp;addr;
        BLYNK_LOG_IP_REV(&quot;Connecting to &quot;, a);
        client = cc3000.connectTCP(addr, port);
        return client.connected();
    }

    void disconnect() { client.stop(); }

    size_t read(void* buf, size_t len) {
        return client.readBytes((char*)buf, len);
    }
    size_t write(const void* buf, size_t len) {
        return client.write((const uint8_t*)buf, len);
    }

    bool connected() { return client.connected(); }
    int available() { return client.available(); }

private:
    Adafruit_CC3000&amp; cc3000;
    Adafruit_CC3000_Client client;
    uint32_t    addr;
    uint16_t    port;
};

class BlynkCC3000
    : public BlynkProtocol&lt;BlynkTransportCC3000&gt;
{
    typedef BlynkProtocol&lt;BlynkTransportCC3000&gt; Base;
public:
    BlynkCC3000(Adafruit_CC3000&amp; cc3000, BlynkTransportCC3000&amp; transp)
        : Base(transp), cc3000(cc3000)
    {}

    void connectWiFi(const char* ssid,
                     const char* pass,
                     uint8_t     secmode)
    {
        if (!cc3000.begin())
        {
            BLYNK_FATAL(&quot;Couldn't begin()! Check your wiring?&quot;);
        }

#if !defined(CC3000_TINY_DRIVER) &amp;&amp; defined(BLYNK_DEBUG)
        uint8_t major, minor;
        if(!cc3000.getFirmwareVersion(&amp;major, &amp;minor))
        {
            if(major != 0x1 || minor &lt; 0x13) {
                BLYNK_LOG1(BLYNK_F(&quot;CC3000 upgrade needed?&quot;));
            }
        }
#endif

        /*if (!cc3000.deleteProfiles())
        {
            BLYNK_FATAL(&quot;Fail deleting old profiles&quot;);
        }*/
        BLYNK_LOG2(BLYNK_F(&quot;Connecting to &quot;), ssid);
        if (!cc3000.connectToAP(ssid, pass, secmode))
        {
            BLYNK_FATAL(&quot;Failed to connect to AP&quot;);
        }
        BLYNK_LOG1(BLYNK_F(&quot;Getting IP...&quot;));
        while (!cc3000.checkDHCP())
        {
            ::delay(100);
        }

        uint32_t ipAddress, netmask, gateway, dhcpserv, dnsserv;
        if(!cc3000.getIPAddress(&amp;ipAddress, &amp;netmask, &amp;gateway, &amp;dhcpserv, &amp;dnsserv))
        {
            BLYNK_FATAL(&quot;DHCP failed.&quot;);
        }
#ifdef BLYNK_PRINT
        uint8_t* addr = (uint8_t*)&amp;ipAddress;
        BLYNK_LOG_IP_REV(&quot;IP: &quot;, addr);
        addr = (uint8_t*)&amp;gateway;
        BLYNK_LOG_IP_REV(&quot;GW: &quot;, addr);
        addr = (uint8_t*)&amp;dnsserv;
        BLYNK_LOG_IP_REV(&quot;DNS: &quot;, addr);
#endif
    }

    void config(const char* auth,
            	const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        Base::begin(auth);
        uint32_t ip = 0;
        BLYNK_LOG2(BLYNK_F(&quot;Looking for &quot;), domain);
        while (ip == 0) {
            if (!cc3000.getHostByName((char*)domain, &amp;ip)) {
                BLYNK_LOG1(BLYNK_F(&quot;Couldn't locate server&quot;));
                ::delay(500);
            }
        }
        this-&gt;conn.begin(ip, port);
    }

    void config(const char* auth,
            	IPAddress   ip,
                uint16_t    port = BLYNK_DEFAULT_PORT)
    {
        Base::begin(auth);
        this-&gt;conn.begin(cc3000.IP2U32(ip[0],ip[1],ip[2],ip[3]), port);
    }

    void begin( const char* auth,
                const char* ssid,
                const char* pass,
                uint8_t     secmode,
                const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        connectWiFi(ssid, pass, secmode);
        config(auth, domain, port);
    }

    void begin( const char* auth,
                const char* ssid,
                const char* pass,
                uint8_t     secmode,
                IPAddress   ip,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        connectWiFi(ssid, pass, secmode);
        config(auth, ip, port);
    }
private:
    Adafruit_CC3000&amp; cc3000;
};

#endif
