/**
 * @file       BlynkWiFly.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2015
 * @brief
 *
 */

#ifndef BlynkWiFly_h
#define BlynkWiFly_h

#ifndef BLYNK_INFO_CONNECTION
#define BLYNK_INFO_CONNECTION &quot;RN-XV&quot;
#endif

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;WiFlyHQ.h&gt;

class BlynkTransportWiFly
{
public:
    BlynkTransportWiFly()
        : wifly(NULL)
        , domain(NULL)
        , port(0)
    {}

    void begin_domain(WiFly* rnxv, const char* h,  uint16_t p) {
        wifly = rnxv;
        domain = h;
        port = p;
    }

    bool connect() {
        return wifly-&gt;open(domain, port);
    }
    void disconnect() { wifly-&gt;close(); }

    size_t read(void* buf, size_t len) {
        return wifly-&gt;readBytes((char*)buf, len);
    }
    size_t write(const void* buf, size_t len) {
        wifly-&gt;write((const uint8_t*)buf, len);
        return len;
    }

    bool connected() { return wifly-&gt;isConnected(); }
    int available() { return wifly-&gt;available(); }

private:
    WiFly*      wifly;
    const char* domain;
    uint16_t    port;
};

class BlynkWiFly
    : public BlynkProtocol&lt;BlynkTransportWiFly&gt;
{
    typedef BlynkProtocol&lt;BlynkTransportWiFly&gt; Base;
public:
    BlynkWiFly(BlynkTransportWiFly&amp; transp)
        : Base(transp)
        , wifly(NULL)
    {}

    void connectWiFi(const char* ssid, const char* pass) {
        if (!wifly-&gt;isAssociated()) {
            BLYNK_LOG2(BLYNK_F(&quot;Connecting to &quot;), ssid);
            wifly-&gt;setSSID(ssid);
            if (pass &amp;&amp; strlen(pass)) {
                 wifly-&gt;setPassphrase(pass);
            }
            wifly-&gt;enableDHCP();
            if (!wifly-&gt;join()) {
                BLYNK_FATAL(&quot;Failed.&quot;);
            }
        } else {
            BLYNK_LOG1(BLYNK_F(&quot;Already connected to WiFi&quot;));
        }
        if (wifly-&gt;isConnected()) {
            wifly-&gt;close();
        }
        wifly-&gt;setIpFlags(1 &lt;&lt; 1);
    }

    void config(WiFly&amp;      rnxv,
                const char* auth,
                const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        Base::begin(auth);
        wifly = &amp;rnxv;
        this-&gt;conn.begin_domain(wifly, domain, port);
    }

    void begin( const char* auth,
                WiFly&amp;      rnxv,
                const char* ssid,
                const char* pass,
                const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        wifly = &amp;rnxv;
        connectWiFi(ssid, pass);
        config(rnxv, auth, domain, port);
    }

private:
    WiFly* wifly;
};

#endif
