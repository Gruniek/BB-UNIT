/**
 * @file       BlynkSimpleEthernet.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2015
 * @brief
 *
 */

#ifndef BlynkSimpleEthernetV2_0_h
#define BlynkSimpleEthernetV2_0_h

#ifndef BLYNK_INFO_CONNECTION
#define BLYNK_INFO_CONNECTION &quot;W5200&quot;
#endif

#include &lt;EthernetV2_0.h&gt;
#include &lt;Adapters/BlynkEthernet.h&gt;

static EthernetClient _blynkEthernetClient;
static BlynkArduinoClient _blynkTransport(_blynkEthernetClient);
BlynkEthernet Blynk(_blynkTransport);

#include &lt;BlynkWidgets.h&gt;

#endif
