/**
 * @file       BlynkWidgets.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Mar 2015
 * @brief
 */

#include &lt;WidgetLED.h&gt;
#include &lt;WidgetLCD.h&gt;
#include &lt;WidgetTerminal.h&gt;
#include &lt;WidgetBridge.h&gt;
// Cannot auto-include WidgetSD, as it has library dependency
