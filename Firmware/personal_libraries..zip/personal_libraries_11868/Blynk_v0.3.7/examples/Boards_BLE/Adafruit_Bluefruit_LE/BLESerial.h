#ifndef _BLE_SERIAL_H_
#define _BLE_SERIAL_H_

#include &lt;Arduino.h&gt;
#include &lt;BLEPeripheral.h&gt;

class BLESerial : public BLEPeripheral, public Stream
{
  public:
    BLESerial(unsigned char req, unsigned char rdy, unsigned char rst);

    void begin(...);
    void poll();
    void end();

    virtual int available(void);
    virtual int peek(void);
    virtual int read(void);
    virtual void flush(void);
    virtual size_t write(uint8_t byte);
    virtual size_t write(const uint8_t *buff, size_t len);
    using Print::write;
    virtual operator bool();

  private:
    static BLESerial* _instance;

    size_t _rxHead;
    size_t _rxTail;
    size_t _rxCount() const;
    uint8_t _rxBuffer[256];

    BLEService _uartService = BLEService(&quot;6E400001-B5A3-F393-E0A9-E50E24DCCA9E&quot;);
    BLEDescriptor _uartNameDescriptor = BLEDescriptor(&quot;2901&quot;, &quot;UART&quot;);
    BLECharacteristic _rxCharacteristic = BLECharacteristic(&quot;6E400002-B5A3-F393-E0A9-E50E24DCCA9E&quot;, BLEWriteWithoutResponse | BLEWrite, BLE_ATTRIBUTE_MAX_VALUE_LENGTH);
    BLEDescriptor _rxNameDescriptor = BLEDescriptor(&quot;2901&quot;, &quot;RX - Receive Data (Write)&quot;);
    BLECharacteristic _txCharacteristic = BLECharacteristic(&quot;6E400003-B5A3-F393-E0A9-E50E24DCCA9E&quot;, BLERead | BLENotify, BLE_ATTRIBUTE_MAX_VALUE_LENGTH);
    BLEDescriptor _txNameDescriptor = BLEDescriptor(&quot;2901&quot;, &quot;TX - Transfer Data (Notify)&quot;);

    void _received(const uint8_t* data, size_t size);
    static void _received(BLECentral&amp; /*central*/, BLECharacteristic&amp; rxCharacteristic);
};

#endif
