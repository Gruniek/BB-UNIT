#include &quot;BLESerial.h&quot;

BLESerial* BLESerial::_instance = NULL;

BLESerial::BLESerial(unsigned char req, unsigned char rdy, unsigned char rst) :
  BLEPeripheral(req, rdy, rst)
{
  this-&gt;_rxHead = this-&gt;_rxTail = 0;
  BLESerial::_instance = this;

  addAttribute(this-&gt;_uartService);
  addAttribute(this-&gt;_uartNameDescriptor);
  setAdvertisedServiceUuid(this-&gt;_uartService.uuid());
  addAttribute(this-&gt;_rxCharacteristic);
  //addAttribute(this-&gt;_rxNameDescriptor);
  addAttribute(this-&gt;_txCharacteristic);
  //addAttribute(this-&gt;_txNameDescriptor);
  this-&gt;_rxCharacteristic.setEventHandler(BLEWritten, BLESerial::_received);
}

void BLESerial::begin(...) {
  BLEPeripheral::begin();
}

void BLESerial::poll() {
  BLEPeripheral::poll();
}

void BLESerial::end() {
  this-&gt;_rxCharacteristic.setEventHandler(BLEWritten, NULL);
  this-&gt;_rxHead = this-&gt;_rxTail = 0;
  BLEPeripheral::disconnect();
}

int BLESerial::available(void) {
  BLEPeripheral::poll();
  int retval = (this-&gt;_rxHead - this-&gt;_rxTail + sizeof(this-&gt;_rxBuffer)) % sizeof(this-&gt;_rxBuffer);
  return retval;
}

int BLESerial::peek(void) {
  BLEPeripheral::poll();
  if (this-&gt;_rxTail == this-&gt;_rxHead) return -1;
  uint8_t byte = this-&gt;_rxBuffer[this-&gt;_rxTail];
  return byte;
}

int BLESerial::read(void) {
  BLEPeripheral::poll();
  if (this-&gt;_rxTail == this-&gt;_rxHead) return -1;
  this-&gt;_rxTail = (this-&gt;_rxTail + 1) % sizeof(this-&gt;_rxBuffer);
  uint8_t byte = this-&gt;_rxBuffer[this-&gt;_rxTail];
  return byte;
}

void BLESerial::flush(void) {
  this-&gt;_rxHead = this-&gt;_rxTail = 0;
}

size_t BLESerial::write(const uint8_t* buff, size_t len) {
  this-&gt;_txCharacteristic.setValue(buff, len);
  BLEPeripheral::poll();
  return len;
}

size_t BLESerial::write(uint8_t byte) {
  Serial.print(F(&quot;BLESerial::write should not be called!&quot;));
  for(;;);
  return -1;
}

BLESerial::operator bool() {
  bool retval = BLEPeripheral::connected();
  return retval;
}

void BLESerial::_received(const uint8_t* data, size_t size) {
  for (int i = 0; i &lt; size; i++) {
    this-&gt;_rxHead = (this-&gt;_rxHead + 1) % sizeof(this-&gt;_rxBuffer);
    this-&gt;_rxBuffer[this-&gt;_rxHead] = data[i];
  }
}

void BLESerial::_received(BLECentral&amp; /*central*/, BLECharacteristic&amp; rxCharacteristic) {
  BLESerial::_instance-&gt;_received(rxCharacteristic.value(), rxCharacteristic.valueLength());
}
