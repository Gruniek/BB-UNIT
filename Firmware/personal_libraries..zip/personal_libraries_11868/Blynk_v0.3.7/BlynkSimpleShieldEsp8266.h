/**
 * @file       BlynkSimpleShieldEsp8266.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jun 2015
 * @brief
 *
 */

#ifndef BlynkSimpleShieldEsp8266_h
#define BlynkSimpleShieldEsp8266_h

#ifdef ESP8266
#error This code is not intended to run on the ESP8266 platform! Please check your Tools-&gt;Board setting.
#endif

#ifndef BLYNK_INFO_CONNECTION
#define BLYNK_INFO_CONNECTION  &quot;ESP8266&quot;
#endif

#define BLYNK_SEND_ATOMIC

// TODO: Remove this hotfix
#define BLYNK_NO_INFO

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;utility/BlynkFifo.h&gt;
#include &lt;ESP8266_Lib.h&gt;

class BlynkTransportShieldEsp8266
{
    static void onData(uint8_t mux_id, uint32_t len, void* ptr) {
        ((BlynkTransportShieldEsp8266*)ptr)-&gt;onData(mux_id, len);
    }

    void onData(uint8_t mux_id, uint32_t len) {
        //BLYNK_LOG2(&quot;Got &quot;, len);
        while (len) {
            if (client-&gt;getUart()-&gt;available()) {
                uint8_t b = client-&gt;getUart()-&gt;read();
                if(!buffer.push(b)) {
                    BLYNK_LOG1(BLYNK_F(&quot;Buffer overflow&quot;));
                }
                len--;
            }
        }
    }

public:
    BlynkTransportShieldEsp8266()
        : client(NULL)
        , status(false)
        , domain(NULL)
        , port(0)
    {}

    void begin_domain(ESP8266* esp8266, const char* d,  uint16_t p) {
        client = esp8266;
        client-&gt;setOnData(onData, this);
        domain = d;
        port = p;
    }

    bool connect() {
        if (!domain || !port)
            return false;
        status = client-&gt;createTCP(domain, port);
        return status;
    }

    void disconnect() {
        status = false;
        buffer.clear();
        client-&gt;releaseTCP();
    }

    size_t read(void* buf, size_t len) {
        uint32_t start = millis();
        //BLYNK_LOG4(&quot;Waiting: &quot;, len, &quot; Occuied: &quot;, buffer.getOccupied());
        while ((buffer.getOccupied() &lt; len) &amp;&amp; (millis() - start &lt; 1500)) {
            client-&gt;run();
        }
        return buffer.read((uint8_t*)buf, len);
    }
    size_t write(const void* buf, size_t len) {
        if (client-&gt;send((const uint8_t*)buf, len)) {
            return len;
        }
        return 0;
    }

    bool connected() { return status; }

    int available() {
        client-&gt;run();
        //BLYNK_LOG2(&quot;Still: &quot;, buffer.getOccupied());
        return buffer.getOccupied();
    }

private:
    ESP8266* client;
    bool status;
    BlynkFifo&lt;uint8_t,256&gt; buffer;
    const char* domain;
    uint16_t    port;
};

class BlynkWifi
    : public BlynkProtocol&lt;BlynkTransportShieldEsp8266&gt;
{
    typedef BlynkProtocol&lt;BlynkTransportShieldEsp8266&gt; Base;
public:
    BlynkWifi(BlynkTransportShieldEsp8266&amp; transp)
        : Base(transp)
        , wifi(NULL)
    {}

    bool connectWiFi(const char* ssid, const char* pass)
    {
        delay(500);
        BLYNK_LOG2(BLYNK_F(&quot;Connecting to &quot;), ssid);
        /*if (!wifi-&gt;restart()) {
            BLYNK_LOG1(BLYNK_F(&quot;Failed to restart&quot;));
            return false;
        }*/
        if (!wifi-&gt;setEcho(0)) {
            BLYNK_LOG1(BLYNK_F(&quot;Failed to disable Echo&quot;));
            return false;
        }
        if (!wifi-&gt;setOprToStation()) {
            BLYNK_LOG1(BLYNK_F(&quot;Failed to set STA mode&quot;));
            return false;
        }
        if (wifi-&gt;joinAP(ssid, pass)) {
            BLYNK_LOG2(BLYNK_F(&quot;IP: &quot;), wifi-&gt;getLocalIP().c_str());
        } else {
            BLYNK_LOG1(BLYNK_F(&quot;Failed to connect WiFi&quot;));
            return false;
        }
        if (!wifi-&gt;disableMUX()) {
            BLYNK_LOG1(BLYNK_F(&quot;Failed to disable MUX&quot;));
        }
        BLYNK_LOG1(BLYNK_F(&quot;Connected to WiFi&quot;));
        return true;
    }

    void config(ESP8266&amp;    esp8266,
                const char* auth,
                const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        Base::begin(auth);
        wifi = &amp;esp8266;
        this-&gt;conn.begin_domain(wifi, domain, port);
    }

    void begin(const char* auth,
               ESP8266&amp;    esp8266,
               const char* ssid,
               const char* pass,
               const char* domain = BLYNK_DEFAULT_DOMAIN,
               uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        config(esp8266, auth, domain, port);
        connectWiFi(ssid, pass);
    }

private:
    ESP8266* wifi;
};

static BlynkTransportShieldEsp8266 _blynkTransport;
BlynkWifi Blynk(_blynkTransport);

#include &lt;BlynkWidgets.h&gt;

#endif
