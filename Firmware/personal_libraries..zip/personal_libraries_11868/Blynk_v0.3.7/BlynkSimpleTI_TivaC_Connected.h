/**
 * @file       BlynkSimpleEthernet.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2015
 * @brief
 *
 */

#ifndef BlynkSimpleTivaC_Connected_h
#define BlynkSimpleTivaC_Connected_h

#ifndef BLYNK_INFO_DEVICE
#define BLYNK_INFO_DEVICE  &quot;TI Tiva C Connected&quot;
#endif

#ifndef BLYNK_INFO_CONNECTION
#define BLYNK_INFO_CONNECTION &quot;TM4C12x&quot;
#endif

#include &lt;Ethernet.h&gt;
#include &lt;EthernetClient.h&gt;
#include &lt;Adapters/BlynkEthernet.h&gt;

static EthernetClient _blynkEthernetClient;
static BlynkArduinoClient _blynkTransport(_blynkEthernetClient);
BlynkEthernet Blynk(_blynkTransport);

#include &lt;BlynkWidgets.h&gt;

#endif
