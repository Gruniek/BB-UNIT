/**
 * @file       BlynkApiArduino.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Mar 2015
 * @brief
 *
 */

#ifndef BlynkApiArduino_h
#define BlynkApiArduino_h

#include &lt;Blynk/BlynkApi.h&gt;
#include &lt;Arduino.h&gt;

template&lt;class Proto&gt;
void BlynkApi&lt;Proto&gt;::Init()
{
}

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
millis_time_t BlynkApi&lt;Proto&gt;::getMillis()
{
// TODO: Remove workaround for Intel Curie
// https://forum.arduino.cc/index.php?topic=391836.0
#ifdef ARDUINO_ARCH_ARC32
	noInterrupts();
	uint64_t t = millis();
	interrupts();
	return t;
#else
    return millis();
#endif
}

#ifdef BLYNK_NO_INFO

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
void BlynkApi&lt;Proto&gt;::sendInfo() {}

#else

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
void BlynkApi&lt;Proto&gt;::sendInfo()
{
    static const char profile[] BLYNK_PROGMEM =
        BLYNK_PARAM_KV(&quot;ver&quot;    , BLYNK_VERSION)
        BLYNK_PARAM_KV(&quot;h-beat&quot; , TOSTRING(BLYNK_HEARTBEAT))
        BLYNK_PARAM_KV(&quot;buff-in&quot;, TOSTRING(BLYNK_MAX_READBYTES))
#ifdef BLYNK_INFO_DEVICE
        BLYNK_PARAM_KV(&quot;dev&quot;    , BLYNK_INFO_DEVICE)
#endif
#ifdef BLYNK_INFO_CPU
        BLYNK_PARAM_KV(&quot;cpu&quot;    , BLYNK_INFO_CPU)
#endif
#ifdef BLYNK_INFO_CONNECTION
        BLYNK_PARAM_KV(&quot;con&quot;    , BLYNK_INFO_CONNECTION)
#endif
        BLYNK_PARAM_KV(&quot;build&quot;  , __DATE__ &quot; &quot; __TIME__)
    ;
    const size_t profile_len = sizeof(profile)-1;

#ifdef BLYNK_HAS_PROGMEM
    char mem[profile_len];
    memcpy_P(mem, profile, profile_len);
    static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_HARDWARE_INFO, 0, mem, profile_len);
#else
    static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_HARDWARE_INFO, 0, profile, profile_len);
#endif
    return;
}

#endif

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
void BlynkApi&lt;Proto&gt;::processCmd(const void* buff, size_t len)
{
    BlynkParam param((void*)buff, len);
    BlynkParam::iterator it = param.begin();
    if (it &gt;= param.end())
        return;
    const char* cmd = it.asStr();
#if defined(MPIDE)
    uint16_t cmd16;
    memcpy(&amp;cmd16, cmd, sizeof(cmd16));
#else
    const uint16_t cmd16 = *(uint16_t*)cmd;
#endif
    if (++it &gt;= param.end())
        return;

#if defined(analogInputToDigitalPin)
    // Good! Analog pins can be referenced on this device by name.
    const uint8_t pin = (it.asStr()[0] == 'A') ?
                         analogInputToDigitalPin(atoi(it.asStr()+1)) :
                         it.asInt();
#else
    #warning &quot;analogInputToDigitalPin not defined =&gt; Named analog pins will not work&quot;
    const uint8_t pin = it.asInt();
#endif

    switch(cmd16) {

#ifndef BLYNK_NO_BUILTIN

    case BLYNK_HW_PM: {
        while (it &lt; param.end()) {
            ++it;
            if (!strcmp(it.asStr(), &quot;in&quot;)) {
                pinMode(pin, INPUT);
            } else if (!strcmp(it.asStr(), &quot;out&quot;) || !strcmp(it.asStr(), &quot;pwm&quot;)) {
                pinMode(pin, OUTPUT);
#ifdef INPUT_PULLUP
            } else if (!strcmp(it.asStr(), &quot;pu&quot;)) {
                pinMode(pin, INPUT_PULLUP);
#endif
#ifdef INPUT_PULLDOWN
            } else if (!strcmp(it.asStr(), &quot;pd&quot;)) {
                pinMode(pin, INPUT_PULLDOWN);
#endif
            } else {
#ifdef BLYNK_DEBUG
                BLYNK_LOG4(BLYNK_F(&quot;Invalid pin &quot;), pin, BLYNK_F(&quot; mode &quot;), it.asStr());
#endif
            }
            ++it;
        }
    } break;
    case BLYNK_HW_DR: {
        char mem[16];
        BlynkParam rsp(mem, 0, sizeof(mem));
        rsp.add(&quot;dw&quot;);
        rsp.add(pin);
        rsp.add(digitalRead(pin));
        static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_HARDWARE, 0, rsp.getBuffer(), rsp.getLength()-1);
    } break;
    case BLYNK_HW_DW: {
        // Should be 1 parameter (value)
        if (++it &gt;= param.end())
            return;

#ifdef ESP8266
        // Disable PWM...
        analogWrite(pin, 0);
#endif
#ifndef BLYNK_MINIMIZE_PINMODE_USAGE
        pinMode(pin, OUTPUT);
#endif
        digitalWrite(pin, it.asInt() ? HIGH : LOW);
    } break;
    case BLYNK_HW_AR: {
        char mem[16];
        BlynkParam rsp(mem, 0, sizeof(mem));
        rsp.add(&quot;aw&quot;);
        rsp.add(pin);
        rsp.add(analogRead(pin));
        static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_HARDWARE, 0, rsp.getBuffer(), rsp.getLength()-1);
    } break;
    case BLYNK_HW_AW: {
        // Should be 1 parameter (value)
        if (++it &gt;= param.end())
            return;

#ifndef BLYNK_MINIMIZE_PINMODE_USAGE
        pinMode(pin, OUTPUT);
#endif
        analogWrite(pin, it.asInt());
    } break;

#endif

    case BLYNK_HW_VR: {
        BlynkReq req = { pin };
        WidgetReadHandler handler = GetReadHandler(pin);
        if (handler &amp;&amp; (handler != BlynkWidgetRead)) {
            handler(req);
        } else {
            BlynkWidgetReadDefault(req);
        }
    } break;
    case BLYNK_HW_VW: {
        ++it;
        char* start = (char*)it.asStr();
        BlynkParam param2(start, len - (start - (char*)buff));
        BlynkReq req = { pin };
        WidgetWriteHandler handler = GetWriteHandler(pin);
        if (handler &amp;&amp; (handler != BlynkWidgetWrite)) {
            handler(req, param2);
        } else {
            BlynkWidgetWriteDefault(req, param2);
        }
    } break;
    default:
        BLYNK_LOG2(BLYNK_F(&quot;Invalid HW cmd: &quot;), cmd);
        static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_RESPONSE, static_cast&lt;Proto*&gt;(this)-&gt;currentMsgId, NULL, BLYNK_ILLEGAL_COMMAND);
    }
}

#endif
