/**
 * @file       BlynkSimpleLinkItONE.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jul 2015
 * @brief
 *
 */

#ifndef BlynkSimpleLinkItONE_h
#define BlynkSimpleLinkItONE_h

#ifndef BLYNK_INFO_DEVICE
#define BLYNK_INFO_DEVICE  &quot;LinkIt ONE&quot;
#endif

// cause this causes crashes...
#define BLYNK_NO_YIELD

#include &lt;BlynkApiArduino.h&gt;
#include &lt;Blynk/BlynkProtocol.h&gt;
#include &lt;Adapters/BlynkArduinoClient.h&gt;
#include &lt;LWiFi.h&gt;
#include &lt;LWiFiClient.h&gt;

class BlynkLinkItOneWifi
    : public BlynkProtocol&lt;BlynkArduinoClient&gt;
{
    typedef BlynkProtocol&lt;BlynkArduinoClient&gt; Base;
public:
    BlynkLinkItOneWifi(BlynkArduinoClient&amp; transp)
        : Base(transp)
    {}

    void connectWiFi(const char* ssid, const char* pass, int wifi_auth)
    {
        BLYNK_LOG2(BLYNK_F(&quot;Connecting to &quot;), ssid);
        LWiFi.begin();
        while(!LWiFi.connect(ssid, LWiFiLoginInfo((LWiFiEncryption)wifi_auth, pass))){
            ::delay(1000);
        }
    }

    void config(const char* auth,
                const char* domain = BLYNK_DEFAULT_DOMAIN,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
        Base::begin(auth);
        this-&gt;conn.begin(domain, port);
    }

    void config(const char* auth,
            	IPAddress   ip,
                uint16_t    port   = BLYNK_DEFAULT_PORT)
    {
    	Base::begin(auth);
    	this-&gt;conn.begin(ip, port);
    }

    void begin(const char* auth,
               const char* ssid,
               const char* pass,
               int         wifi_auth,
               const char* domain = BLYNK_DEFAULT_DOMAIN,
               uint16_t port      = BLYNK_DEFAULT_PORT)
    {
        connectWiFi(ssid, pass, wifi_auth);
        config(auth, domain, port);
    }

    void begin(const char* auth,
               const char* ssid,
               const char* pass,
			   int         wifi_auth,
               IPAddress   ip,
               uint16_t    port = BLYNK_DEFAULT_PORT)
    {
        connectWiFi(ssid, pass, wifi_auth);
    	config(auth, ip, port);
    }

};


static LWiFiClient _blynkWifiClient;
static BlynkArduinoClient _blynkTransport(_blynkWifiClient);
BlynkLinkItOneWifi Blynk(_blynkTransport);

#include &lt;BlynkWidgets.h&gt;

#endif
