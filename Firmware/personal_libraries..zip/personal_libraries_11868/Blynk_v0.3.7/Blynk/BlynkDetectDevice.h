/**
 * @file       BlynkDetectDevice.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2016 Volodymyr Shymanskyy
 * @date       May 2016
 * @brief
 *
 */

#ifndef BlynkDetectDevice_h
#define BlynkDetectDevice_h

#ifndef BLYNK_INFO_CPU

    /******************************************
     * ATmega
     */

    #if   defined(__AVR_ATmega168__)
    #define BLYNK_INFO_CPU      &quot;ATmega168&quot;
    #elif defined(__AVR_ATmega328P__)
    #define BLYNK_INFO_CPU      &quot;ATmega328P&quot;
    #elif defined(__AVR_ATmega1280__)
    #define BLYNK_INFO_CPU      &quot;ATmega1280&quot;
    #elif defined(__AVR_ATmega1284__)
    #define BLYNK_INFO_CPU      &quot;ATmega1284&quot;
    #elif defined(__AVR_ATmega2560__)
    #define BLYNK_INFO_CPU      &quot;ATmega2560&quot;
    #elif defined(__AVR_ATmega32U4__)
    #define BLYNK_INFO_CPU      &quot;ATmega32U4&quot;
    #elif defined(__SAM3X8E__)
    #define BLYNK_INFO_CPU      &quot;AT91SAM3X8E&quot;

    /******************************************
     * ATtiny
     */

    #elif defined(__AVR_ATtiny25__)
    #define BLYNK_INFO_CPU      &quot;ATtiny25&quot;
    #elif defined(__AVR_ATtiny45__)
    #define BLYNK_INFO_CPU      &quot;ATtiny45&quot;
    #elif defined(__AVR_ATtiny85__)
    #define BLYNK_INFO_CPU      &quot;ATtiny85&quot;
    #elif defined(__AVR_ATtiny24__)
    #define BLYNK_INFO_CPU      &quot;ATtiny24&quot;
    #elif defined(__AVR_ATtiny44__)
    #define BLYNK_INFO_CPU      &quot;ATtiny44&quot;
    #elif defined(__AVR_ATtiny84__)
    #define BLYNK_INFO_CPU      &quot;ATtiny84&quot;
    #elif defined(__AVR_ATtiny2313__)
    #define BLYNK_INFO_CPU      &quot;ATtiny2313&quot;
    #elif defined(__AVR_ATtiny4313__)
    #define BLYNK_INFO_CPU      &quot;ATtiny4313&quot;
    #endif
#endif

#ifndef BLYNK_INFO_DEVICE

    #if   defined(ENERGIA)
        #define BLYNK_INFO_DEVICE  &quot;Energia&quot;
        #define BLYNK_USE_128_VPINS

        #if   defined(__MSP430F5529__)
        #define BLYNK_INFO_CPU  &quot;MSP430F5529&quot;
        #define BLYNK_NO_FLOAT
        #endif

    #elif defined(LINUX)

        #define BLYNK_INFO_DEVICE  &quot;Linux&quot;
        #define BLYNK_USE_128_VPINS

    #elif defined(SPARK) || defined(PARTICLE)

        #define BLYNK_USE_128_VPINS

        #if PLATFORM_ID==0
        #define BLYNK_INFO_DEVICE  &quot;Particle Core&quot;
        #elif PLATFORM_ID==6
        #define BLYNK_INFO_DEVICE  &quot;Particle Photon&quot;
        #elif PLATFORM_ID==8
        #define BLYNK_INFO_DEVICE  &quot;Particle P1&quot;
        #elif PLATFORM_ID==9
        #define BLYNK_INFO_DEVICE  &quot;Particle Ethernet&quot;
        #elif PLATFORM_ID==10
        #define BLYNK_INFO_DEVICE  &quot;Particle Electron&quot;
        #elif PLATFORM_ID==82
        #define BLYNK_INFO_DEVICE  &quot;Digistump Oak&quot;
        #elif PLATFORM_ID==88
        #define BLYNK_INFO_DEVICE  &quot;RedBear Duo&quot;
        #elif PLATFORM_ID==103
        #define BLYNK_INFO_DEVICE  &quot;Bluz&quot;
        #else
        #warning &quot;Cannot detect board type&quot;
        #define BLYNK_INFO_DEVICE  &quot;Particle&quot;
        #endif

    #elif defined(MBED_LIBRARY_VERSION)

        #define BLYNK_INFO_DEVICE  &quot;MBED&quot;
        #define BLYNK_USE_128_VPINS

    #elif defined(ARDUINO) &amp;&amp; defined(MPIDE)
        #define BLYNK_NO_YIELD

        #if   defined(_BOARD_UNO_)
        #define BLYNK_INFO_DEVICE  &quot;chipKIT Uno32&quot;
        #else
        #define BLYNK_INFO_DEVICE  &quot;chipKIT&quot;
        #endif

    #elif defined(ARDUINO) &amp;&amp; defined(TEENSYDUINO)

        #if   defined(__MK20DX256__)
        #define BLYNK_INFO_DEVICE  &quot;Teensy 3.2/3.1&quot;
        #define BLYNK_USE_128_VPINS
        #elif   defined(__MK20DX128__)
        #define BLYNK_INFO_DEVICE  &quot;Teensy 3.0&quot;
        #define BLYNK_USE_128_VPINS
        #elif   defined(__MKL26Z64__)
        #define BLYNK_INFO_DEVICE  &quot;Teensy LC&quot;
        #elif   defined(ARDUINO_ARCH_AVR)
        #define BLYNK_INFO_DEVICE  &quot;Teensy 2.0&quot;
        #else
        #define BLYNK_INFO_DEVICE  &quot;Teensy&quot;
        #endif

    #elif defined(ARDUINO)

        #ifdef ESP8266
            #define BLYNK_USE_128_VPINS
        #endif

        /* Arduino AVR */
        #if   defined(ARDUINO_AVR_NANO)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Nano&quot;
        #elif defined(ARDUINO_AVR_UNO) || defined(ARDUINO_AVR_DUEMILANOVE)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Uno&quot;
        #elif defined(ARDUINO_AVR_YUN)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Yun&quot;
        #elif defined(ARDUINO_AVR_MINI)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Mini&quot;
        #elif defined(ARDUINO_AVR_ETHERNET)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Ethernet&quot;
        #elif defined(ARDUINO_AVR_FIO)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Fio&quot;
        #elif defined(ARDUINO_AVR_BT)
        #define BLYNK_INFO_DEVICE  &quot;Arduino BT&quot;
        #elif defined(ARDUINO_AVR_PRO)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Pro&quot;
        #elif defined(ARDUINO_AVR_NG)
        #define BLYNK_INFO_DEVICE  &quot;Arduino NG&quot;
        #elif defined(ARDUINO_AVR_GEMMA)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Gemma&quot;
        #elif defined(ARDUINO_AVR_MEGA) || defined(ARDUINO_AVR_MEGA2560)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Mega&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_AVR_ADK)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Mega ADK&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_AVR_LEONARDO)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Leonardo&quot;
        #elif defined(ARDUINO_AVR_MICRO)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Micro&quot;
        #elif defined(ARDUINO_AVR_ESPLORA)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Esplora&quot;
        #elif defined(ARDUINO_AVR_LILYPAD)
        #define BLYNK_INFO_DEVICE  &quot;Lilypad&quot;
        #elif defined(ARDUINO_AVR_LILYPAD_USB)
        #define BLYNK_INFO_DEVICE  &quot;Lilypad USB&quot;
        #elif defined(ARDUINO_AVR_ROBOT_MOTOR)
        #define BLYNK_INFO_DEVICE  &quot;Robot Motor&quot;
        #elif defined(ARDUINO_AVR_ROBOT_CONTROL)
        #define BLYNK_INFO_DEVICE  &quot;Robot Control&quot;

        /* Arduino SAM/SAMD */
        #elif defined(ARDUINO_SAM_DUE)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Due&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_SAMD_ZERO)
        #define BLYNK_INFO_DEVICE  &quot;Arduino Zero&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_SAMD_MKR1000)
        #define BLYNK_INFO_DEVICE  &quot;Arduino MKR1000&quot;
        #define BLYNK_USE_128_VPINS

        /* Intel */
        #elif defined(ARDUINO_GALILEO)
        #define BLYNK_INFO_DEVICE  &quot;Galileo&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_GALILEOGEN2)
        #define BLYNK_INFO_DEVICE  &quot;Galileo Gen2&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_EDISON)
        #define BLYNK_INFO_DEVICE  &quot;Edison&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_ARCH_ARC32) // TODO
        #define BLYNK_INFO_DEVICE  &quot;Arduino 101&quot;
        #define BLYNK_USE_128_VPINS

        /* Konekt */
        #elif defined(ARDUINO_DASH)
        #define BLYNK_INFO_DEVICE  &quot;Dash&quot;
        #elif defined(ARDUINO_DASHPRO)
        #define BLYNK_INFO_DEVICE  &quot;Dash Pro&quot;

        /* Red Bear Lab */
        #elif defined(ARDUINO_RedBear_Duo)
        #define BLYNK_INFO_DEVICE  &quot;RedBear Duo&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_BLEND)
        #define BLYNK_INFO_DEVICE  &quot;Blend&quot;
        #elif defined(ARDUINO_BLEND_MICRO_8MHZ) || defined(ARDUINO_BLEND_MICRO_16MHZ)
        #define BLYNK_INFO_DEVICE  &quot;Blend Micro&quot;
        #elif defined(ARDUINO_RBL_nRF51822)
        #define BLYNK_INFO_DEVICE  &quot;BLE Nano&quot;

        /* ESP8266 */
        #elif defined(ARDUINO_ESP8266_ESP01)
        #define BLYNK_INFO_DEVICE  &quot;ESP8266&quot;
        #elif defined(ARDUINO_ESP8266_ESP12)
        #define BLYNK_INFO_DEVICE  &quot;ESP-12&quot;
        #elif defined(ARDUINO_ESP8266_NODEMCU)
        #define BLYNK_INFO_DEVICE  &quot;NodeMCU&quot;
        #elif defined(ARDUINO_ESP8266_THING)
        #define BLYNK_INFO_DEVICE  &quot;Esp Thing&quot;
        #elif defined(ARDUINO_ESP8266_THING_DEV)
        #define BLYNK_INFO_DEVICE  &quot;Esp Thing Dev&quot;

        /* Digistump */
        #elif defined(ARDUINO_ESP8266_OAK)
        #define BLYNK_INFO_DEVICE  &quot;Oak&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_AVR_DIGISPARK)
        #define BLYNK_INFO_DEVICE  &quot;Digispark&quot;
        #define BLYNK_NO_INFO
        #elif defined(ARDUINO_AVR_DIGISPARKPRO)
        #define BLYNK_INFO_DEVICE  &quot;Digispark Pro&quot;
        #define BLYNK_NO_INFO

        /* Microduino */
        #elif defined(ARDUINO_AVR_USB)
        #define BLYNK_INFO_DEVICE  &quot;CoreUSB&quot;
        #elif defined(ARDUINO_AVR_PLUS)
        #define BLYNK_INFO_DEVICE  &quot;Core+&quot;
        #elif defined(ARDUINO_AVR_RF)
        #define BLYNK_INFO_DEVICE  &quot;CoreRF&quot;

        /* Wildfire */
        #elif defined(ARDUINO_WILDFIRE_V2)
        #define BLYNK_INFO_DEVICE  &quot;Wildfire V2&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_WILDFIRE_V3)
        #define BLYNK_INFO_DEVICE  &quot;Wildfire V3&quot;
        #define BLYNK_USE_128_VPINS
        #elif defined(ARDUINO_WILDFIRE_V4)
        #define BLYNK_INFO_DEVICE  &quot;Wildfire V4&quot;
        #define BLYNK_USE_128_VPINS

        /* Simblee */
        #elif defined(__Simblee__) // TODO: ARDUINO_SIMBLEE bug?
        #define BLYNK_INFO_DEVICE  &quot;Simblee&quot;

        #else
        #warning &quot;Cannot detect board type&quot;
        #define BLYNK_INFO_DEVICE  &quot;Arduino&quot;
        #endif

	#endif
#endif

#endif
