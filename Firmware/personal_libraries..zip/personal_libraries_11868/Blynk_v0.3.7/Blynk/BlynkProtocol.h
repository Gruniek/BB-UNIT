/**
 * @file       BlynkProtocol.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2015
 * @brief      Blynk protocol implementation
 *
 */

#ifndef BlynkProtocol_h
#define BlynkProtocol_h

#include &lt;string.h&gt;
#include &lt;stdlib.h&gt;
#include &lt;Blynk/BlynkDebug.h&gt;
#include &lt;Blynk/BlynkProtocolDefs.h&gt;
#include &lt;Blynk/BlynkApi.h&gt;
#include &lt;utility/BlynkUtility.h&gt;

template &lt;class Transp&gt;
class BlynkProtocol
    : public BlynkApi&lt; BlynkProtocol&lt;Transp&gt; &gt;
{
    friend class BlynkApi&lt; BlynkProtocol&lt;Transp&gt; &gt;;
public:
    enum BlynkState {
        CONNECTING,
        CONNECTED,
        DISCONNECTED,
    };

    BlynkProtocol(Transp&amp; transp)
        : conn(transp)
        , authkey(NULL)
        , lastActivityIn(0)
        , lastActivityOut(0)
        , lastHeartbeat(0)
#ifdef BLYNK_MSG_LIMIT
        , deltaCmd(0)
#endif
        , currentMsgId(0)
        , state(CONNECTING)
    {}

    bool connected() { return state == CONNECTED; }

    bool connect(uint32_t timeout = BLYNK_TIMEOUT_MS*3) {
    	conn.disconnect();
    	state = CONNECTING;
    	millis_time_t started = this-&gt;getMillis();
    	while ((state != CONNECTED) &amp;&amp;
    	       (this-&gt;getMillis() - started &lt; timeout))
    	{
    		run();
    	}
    	return state == CONNECTED;
    }

    void disconnect() {
        conn.disconnect();
        state = DISCONNECTED;
        BLYNK_LOG1(BLYNK_F(&quot;Disconnected&quot;));
    }

    bool run(bool avail = false);

    // TODO: Fixme
    void startSession() {
        conn.connect();
    	state = CONNECTING;
#ifdef BLYNK_MSG_LIMIT
        deltaCmd = 1000;
#endif
    	currentMsgId = 0;
    	lastHeartbeat = lastActivityIn = lastActivityOut = this-&gt;getMillis(); // TODO: - 5005UL
    }

    void sendCmd(uint8_t cmd, uint16_t id = 0, const void* data = NULL, size_t length = 0, const void* data2 = NULL, size_t length2 = 0);

private:
    int readHeader(BlynkHeader&amp; hdr);
    uint16_t getNextMsgId();

protected:
    void begin(const char* auth) {
        BLYNK_LOG1(BLYNK_F(&quot;Blynk v&quot; BLYNK_VERSION &quot; on &quot; BLYNK_INFO_DEVICE));
        this-&gt;authkey = auth;
    }
    bool processInput(void);

    Transp&amp; conn;

private:
    const char* authkey;
    millis_time_t lastActivityIn;
    millis_time_t lastActivityOut;
    union {
    	millis_time_t lastHeartbeat;
    	millis_time_t lastLogin;
    };
#ifdef BLYNK_MSG_LIMIT
    millis_time_t deltaCmd;
#endif
    uint16_t currentMsgId;
protected:
    BlynkState state;
};

template &lt;class Transp&gt;
bool BlynkProtocol&lt;Transp&gt;::run(bool avail)
{
#if !defined(BLYNK_NO_YIELD)
    yield();
#endif

    if (state == DISCONNECTED) {
        return false;
    }

    const bool tconn = conn.connected();

    if (tconn) {
        if (avail || conn.available() &gt; 0) {
            //BLYNK_LOG2(BLYNK_F(&quot;Available: &quot;), conn.available());
            //const unsigned long t = micros();
            if (!processInput()) {
                conn.disconnect();
// TODO: Only when in direct mode?
#ifdef BLYNK_USE_DIRECT_CONNECT
                state = CONNECTING;
#endif
                //BlynkOnDisconnected();
                return false;
            }
            //BLYNK_LOG2(BLYNK_F(&quot;Proc time: &quot;), micros() - t);
        }
    }

    const millis_time_t t = this-&gt;getMillis();

    if (state == CONNECTED) {
        if (!tconn) {
            state = CONNECTING;
            lastHeartbeat = t;
            //BlynkOnDisconnected();
            return false;
        }

        if (t - lastActivityIn &gt; (1000UL * BLYNK_HEARTBEAT + BLYNK_TIMEOUT_MS*3)) {
#ifdef BLYNK_DEBUG
            BLYNK_LOG6(BLYNK_F(&quot;Heartbeat timeout: &quot;), t, BLYNK_F(&quot;, &quot;), lastActivityIn, BLYNK_F(&quot;, &quot;), lastHeartbeat);
#else
            BLYNK_LOG1(BLYNK_F(&quot;Heartbeat timeout&quot;));
#endif
            conn.disconnect();
            state = CONNECTING;
            //BlynkOnDisconnected();
            return false;
        } else if ((t - lastActivityIn  &gt; 1000UL * BLYNK_HEARTBEAT ||
                    t - lastActivityOut &gt; 1000UL * BLYNK_HEARTBEAT) &amp;&amp;
                    t - lastHeartbeat   &gt; BLYNK_TIMEOUT_MS)
        {
            // Send ping if we didn't either send or receive something
            // for BLYNK_HEARTBEAT seconds
            sendCmd(BLYNK_CMD_PING);
            lastHeartbeat = t;
        }
#ifndef BLYNK_USE_DIRECT_CONNECT
    } else if (state == CONNECTING) {
        if (tconn &amp;&amp; (t - lastLogin &gt; BLYNK_TIMEOUT_MS)) {
            BLYNK_LOG1(BLYNK_F(&quot;Login timeout&quot;));
            conn.disconnect();
            state = CONNECTING;
            return false;
        } else if (!tconn &amp;&amp; (t - lastLogin &gt; 5000UL)) {
            conn.disconnect();
            if (!conn.connect()) {
                lastLogin = t;
                return false;
            }

#ifdef BLYNK_MSG_LIMIT
            deltaCmd = 1000;
#endif
            sendCmd(BLYNK_CMD_LOGIN, 1, authkey, strlen(authkey));
            lastLogin = lastActivityOut;
            return true;
        }
#else
    } else if (state == CONNECTING) {
    	if (!tconn)
    		conn.connect();
#endif
    }
    return true;
}

template &lt;class Transp&gt;
BLYNK_FORCE_INLINE
bool BlynkProtocol&lt;Transp&gt;::processInput(void)
{
    BlynkHeader hdr;
    const int ret = readHeader(hdr);

    if (ret == 0) {
        return true; // Considered OK (no data on input)
    }

    if (ret &lt; 0 || hdr.msg_id == 0) {
#ifdef BLYNK_DEBUG
        BLYNK_LOG2(BLYNK_F(&quot;Bad hdr len: &quot;), ret);
#endif
        return false;
    }

    if (hdr.type == BLYNK_CMD_RESPONSE) {
        lastActivityIn = this-&gt;getMillis();

#ifndef BLYNK_USE_DIRECT_CONNECT
        if (state == CONNECTING &amp;&amp; (1 == hdr.msg_id)) {
            switch (hdr.length) {
            case BLYNK_SUCCESS:
            case BLYNK_ALREADY_LOGGED_IN:
                BLYNK_LOG3(BLYNK_F(&quot;Ready (ping: &quot;), lastActivityIn-lastHeartbeat, BLYNK_F(&quot;ms).&quot;));
                lastHeartbeat = lastActivityIn;
                state = CONNECTED;
                this-&gt;sendInfo();
#if !defined(BLYNK_NO_YIELD)
                yield();
#endif
                BlynkOnConnected();
                return true;
            case BLYNK_INVALID_TOKEN:
                BLYNK_LOG1(BLYNK_F(&quot;Invalid auth token&quot;));
                break;
            default:
                BLYNK_LOG2(BLYNK_F(&quot;Connect failed. code: &quot;), hdr.length);
            }
            return false;
        }
        if (BLYNK_NOT_AUTHENTICATED == hdr.length) {
            return false;
        }
#endif
        // TODO: return code may indicate App presence
        return true;
    }

    if (hdr.length &gt; BLYNK_MAX_READBYTES) {
#ifdef BLYNK_DEBUG
        BLYNK_LOG2(BLYNK_F(&quot;Packet too big: &quot;), hdr.length);
#endif
        // TODO: Flush
        conn.connect();
        return true;
    }

    uint8_t inputBuffer[hdr.length+1]; // Add 1 to zero-terminate
    if (hdr.length != conn.read(inputBuffer, hdr.length)) {
#ifdef DEBUG
        BLYNK_LOG1(BLYNK_F(&quot;Can't read body&quot;));
#endif
        return false;
    }
    inputBuffer[hdr.length] = '\0';

    BLYNK_DBG_DUMP(&quot;&gt;&quot;, inputBuffer, hdr.length);

    lastActivityIn = this-&gt;getMillis();

    switch (hdr.type)
    {
    case BLYNK_CMD_LOGIN: {
#ifdef BLYNK_USE_DIRECT_CONNECT
        if (!strncmp(authkey, (char*)inputBuffer, 32)) {
            BLYNK_LOG1(BLYNK_F(&quot;Ready&quot;));
            state = CONNECTED;
            sendCmd(BLYNK_CMD_RESPONSE, hdr.msg_id, NULL, BLYNK_SUCCESS);
            this-&gt;sendInfo();
        } else {
            BLYNK_LOG1(BLYNK_F(&quot;Invalid token&quot;));
            sendCmd(BLYNK_CMD_RESPONSE, hdr.msg_id, NULL, BLYNK_INVALID_TOKEN);
        }
#else
        BLYNK_LOG1(BLYNK_F(&quot;Ready&quot;));
		state = CONNECTED;
		sendCmd(BLYNK_CMD_RESPONSE, hdr.msg_id, NULL, BLYNK_SUCCESS);
		this-&gt;sendInfo();
#endif
    } break;
    case BLYNK_CMD_PING: {
        sendCmd(BLYNK_CMD_RESPONSE, hdr.msg_id, NULL, BLYNK_SUCCESS);
    } break;
    case BLYNK_CMD_HARDWARE:
    case BLYNK_CMD_BRIDGE: {
        currentMsgId = hdr.msg_id;
        this-&gt;processCmd(inputBuffer, hdr.length);
        currentMsgId = 0;
    } break;
    default: {
#ifdef BLYNK_DEBUG
        BLYNK_LOG2(BLYNK_F(&quot;Invalid header type: &quot;), hdr.type);
#endif
        // TODO: Flush
        conn.connect();
    } break;
    }

    return true;
}

template &lt;class Transp&gt;
int BlynkProtocol&lt;Transp&gt;::readHeader(BlynkHeader&amp; hdr)
{
    size_t rlen = conn.read(&amp;hdr, sizeof(hdr));
    if (rlen == 0) {
        return 0;
    }

    if (sizeof(hdr) != rlen) {
        return -1;
    }

    BLYNK_DBG_DUMP(&quot;&gt;&quot;, &amp;hdr, sizeof(BlynkHeader));

    hdr.msg_id = ntohs(hdr.msg_id);
    hdr.length = ntohs(hdr.length);

    return rlen;
}

#ifndef BLYNK_SEND_THROTTLE
#define BLYNK_SEND_THROTTLE 0
#endif

#ifndef BLYNK_SEND_CHUNK
#define BLYNK_SEND_CHUNK 1024 // Just a big number
#endif

template &lt;class Transp&gt;
void BlynkProtocol&lt;Transp&gt;::sendCmd(uint8_t cmd, uint16_t id, const void* data, size_t length, const void* data2, size_t length2)
{
    if (0 == id) {
        id = getNextMsgId();
    }

    if (!conn.connected() || (cmd != BLYNK_CMD_RESPONSE &amp;&amp; cmd != BLYNK_CMD_PING &amp;&amp; cmd != BLYNK_CMD_LOGIN &amp;&amp; state != CONNECTED) ) {
#ifdef BLYNK_DEBUG
        BLYNK_LOG2(BLYNK_F(&quot;Cmd skipped:&quot;), cmd);
#endif
        return;
    }

    const int full_length = (sizeof(BlynkHeader)) +
                            (data  ? length  : 0) +
                            (data2 ? length2 : 0);

#if defined(BLYNK_SEND_ATOMIC) || defined(ESP8266) || defined(SPARK) || defined(PARTICLE) || defined(ENERGIA)
    // Those have more RAM and like single write at a time...

    uint8_t buff[full_length];

    BlynkHeader* hdr = (BlynkHeader*)buff;
    hdr-&gt;type = cmd;
    hdr-&gt;msg_id = htons(id);
    hdr-&gt;length = htons(length+length2);

    size_t pos = sizeof(BlynkHeader);
    if (data &amp;&amp; length) {
        memcpy(buff + pos, data, length);
        pos += length;
    }
    if (data2 &amp;&amp; length2) {
        memcpy(buff + pos, data2, length2);
    }

    size_t wlen = 0;
    while (wlen &lt; full_length) {
        const size_t chunk = BlynkMin(size_t(BLYNK_SEND_CHUNK), full_length - wlen);
		BLYNK_DBG_DUMP(&quot;&lt;&quot;, buff + wlen, chunk);
        const size_t w = conn.write(buff + wlen, chunk);
        delay(BLYNK_SEND_THROTTLE);
    	if (w == 0) {
#ifdef BLYNK_DEBUG
            BLYNK_LOG1(BLYNK_F(&quot;Cmd error&quot;));
#endif
            conn.disconnect();
            state = CONNECTING;
            //BlynkOnDisconnected();
            return;
    	}
        wlen += w;
    }

#else

    BlynkHeader hdr;
    hdr.type = cmd;
    hdr.msg_id = htons(id);
    hdr.length = htons(length+length2);

	BLYNK_DBG_DUMP(&quot;&lt;&quot;, &amp;hdr, sizeof(hdr));
    size_t wlen = conn.write(&amp;hdr, sizeof(hdr));
    delay(BLYNK_SEND_THROTTLE);

    if (cmd != BLYNK_CMD_RESPONSE) {
        if (length) {
            BLYNK_DBG_DUMP(&quot;&lt;&quot;, data, length);
            wlen += conn.write(data, length);
            delay(BLYNK_SEND_THROTTLE);
        }
        if (length2) {
            BLYNK_DBG_DUMP(&quot;&lt;&quot;, data2, length2);
            wlen += conn.write(data2, length2);
            delay(BLYNK_SEND_THROTTLE);
        }
    }

#endif

    if (wlen != full_length) {
#ifdef BLYNK_DEBUG
        BLYNK_LOG4(BLYNK_F(&quot;Sent &quot;), wlen, '/', full_length);
#endif
        conn.disconnect();
        state = CONNECTING;
        //BlynkOnDisconnected();
        return;
    }

#if defined BLYNK_MSG_LIMIT &amp;&amp; BLYNK_MSG_LIMIT &gt; 0
    const millis_time_t ts = this-&gt;getMillis();
    BlynkAverageSample&lt;32&gt;(deltaCmd, ts - lastActivityOut);
    lastActivityOut = ts;
    //BLYNK_LOG2(BLYNK_F(&quot;Delta: &quot;), deltaCmd);
    if (deltaCmd &lt; (1000/BLYNK_MSG_LIMIT)) {
        BLYNK_LOG_TROUBLE(BLYNK_F(&quot;flood-error&quot;));
        conn.disconnect();
        state = CONNECTING;
        //BlynkOnDisconnected();
    }
#else
    lastActivityOut = this-&gt;getMillis();
#endif

}

template &lt;class Transp&gt;
uint16_t BlynkProtocol&lt;Transp&gt;::getNextMsgId()
{
    static uint16_t last = 0;
    if (currentMsgId != 0)
        return currentMsgId;
    if (++last == 0)
        last = 1;
    return last;
}

#endif
