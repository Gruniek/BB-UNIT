/**
 * @file       WidgetBridge.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Apr 2015
 * @brief
 *
 */

#ifndef WidgetBridge_h
#define WidgetBridge_h

#include &lt;Blynk/BlynkApi.h&gt;

class WidgetBridge
{
public:
    WidgetBridge(int vPin)
        : mPin(vPin)
    {}
    void onWrite(BlynkReq&amp; request, const BlynkParam&amp; param) {}

    void setAuthToken(const char* token) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;i&quot;);
        cmd.add(token);
        Blynk.sendCmd(BLYNK_CMD_BRIDGE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    template &lt;typename T&gt;
    void digitalWrite(const T&amp; pin, int val) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;dw&quot;);
        cmd.add(pin);
        cmd.add(val);
        Blynk.sendCmd(BLYNK_CMD_BRIDGE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    template &lt;typename T&gt;
    void analogWrite(const T&amp; pin, int val) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;aw&quot;);
        cmd.add(pin);
        cmd.add(val);
        Blynk.sendCmd(BLYNK_CMD_BRIDGE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    template &lt;typename T&gt;
    void virtualWrite(int pin, const T&amp; data) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;vw&quot;);
        cmd.add(pin);
        cmd.add(data);
        Blynk.sendCmd(BLYNK_CMD_BRIDGE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    template &lt;typename T1, typename T2&gt;
    void virtualWrite(int pin, const T1&amp; data1, const T2&amp; data2) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;vw&quot;);
        cmd.add(pin);
        cmd.add(data1);
        cmd.add(data2);
        Blynk.sendCmd(BLYNK_CMD_HARDWARE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    template &lt;typename T1, typename T2, typename T3&gt;
    void virtualWrite(int pin, const T1&amp; data1, const T2&amp; data2, const T3&amp; data3) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;vw&quot;);
        cmd.add(pin);
        cmd.add(data1);
        cmd.add(data2);
        cmd.add(data3);
        Blynk.sendCmd(BLYNK_CMD_HARDWARE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    template &lt;typename T1, typename T2, typename T3, typename T4&gt;
    void virtualWrite(int pin, const T1&amp; data1, const T2&amp; data2, const T3&amp; data3, const T4&amp; data4) {
        char mem[64];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;vw&quot;);
        cmd.add(pin);
        cmd.add(data1);
        cmd.add(data2);
        cmd.add(data3);
        cmd.add(data4);
        Blynk.sendCmd(BLYNK_CMD_HARDWARE, 0, cmd.getBuffer(), cmd.getLength()-1);
    }

    void virtualWriteBinary(int pin, const void* buff, size_t len) {
        char mem[8];
        BlynkParam cmd(mem, 0, sizeof(mem));
        cmd.add(mPin);
        cmd.add(&quot;vw&quot;);
        cmd.add(pin);
        Blynk.sendCmd(BLYNK_CMD_BRIDGE, 0, cmd.getBuffer(), cmd.getLength(), buff, len);
    }

    void virtualWrite(int pin, const BlynkParam&amp; param) {
        virtualWriteBinary(pin, param.getBuffer(), param.getLength()-1);
    }

private:
    int mPin;
};

#endif
