/**
 * @file       BlynkUtility.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jun 2015
 * @brief      Utility functions
 *
 */

#ifndef BlynkUtility_h
#define BlynkUtility_h

template&lt;class T&gt;
const T&amp; BlynkMin(const T&amp; a, const T&amp; b)
{
    return (b &lt; a) ? b : a;
}

template&lt;class T&gt;
const T&amp; BlynkMax(const T&amp; a, const T&amp; b)
{
    return (b &lt; a) ? a : b;
}

template &lt;unsigned WSIZE, typename T&gt;
void BlynkAverageSample (T&amp; avg, const T&amp; input) {
    avg -= avg/WSIZE;
    const T add = input/WSIZE;
    // Fix for shorter delays
    avg += (add &gt; 0) ? add : -1;
}

#endif
