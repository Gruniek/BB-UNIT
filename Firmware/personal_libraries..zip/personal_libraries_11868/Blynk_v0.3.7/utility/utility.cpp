#include &lt;Blynk/BlynkDebug.h&gt;

#if defined(ESP8266) &amp;&amp; !defined(BLYNK_NO_FLOAT)
#include &lt;string.h&gt;
#include &lt;math.h&gt;

char* dtostrf_internal(double number, signed char width, unsigned char prec, char *s) {
    if(isnan(number)) {
        strcpy(s, &quot;nan&quot;);
        return s;
    }
    if(isinf(number)) {
        strcpy(s, &quot;inf&quot;);
        return s;
    }

    if(number &gt; 4294967040.0 || number &lt; -4294967040.0) {
        strcpy(s, &quot;ovf&quot;);
        return s;
    }
    char* out = s;
    // Handle negative numbers
    if(number &lt; 0.0) {
        *out = '-';
        ++out;
        number = -number;
    }

    // Round correctly so that print(1.999, 2) prints as &quot;2.00&quot;
    double rounding = 0.5;
    for(uint8_t i = 0; i &lt; prec; ++i)
        rounding /= 10.0;

    number += rounding;

    // Extract the integer part of the number and print it
    unsigned long int_part = (unsigned long) number;
    double remainder = number - (double) int_part;
    out += sprintf(out, &quot;%d&quot;, int_part);

    // Print the decimal point, but only if there are digits beyond
    if(prec &gt; 0) {
        *out = '.';
        ++out;
    }

    while(prec-- &gt; 0) {
        remainder *= 10.0;
        if((int)remainder == 0){
                *out = '0';
                 ++out;
        }
    }
    sprintf(out, &quot;%d&quot;, (int) remainder);

    return s;
}

#endif

