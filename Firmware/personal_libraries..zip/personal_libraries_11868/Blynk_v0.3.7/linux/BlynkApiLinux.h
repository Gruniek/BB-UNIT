/**
 * @file       BlynkApiLinux.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Mar 2015
 * @brief
 *
 */

#ifndef BlynkApiLinux_h
#define BlynkApiLinux_h

#include &lt;Blynk/BlynkApi.h&gt;

#define _POSIX_C_SOURCE 200809L
#include &lt;time.h&gt;
#include &lt;unistd.h&gt;

#ifndef BLYNK_INFO_DEVICE
    #define BLYNK_INFO_DEVICE  &quot;Linux&quot;
#endif

static inline
void delay(unsigned long ms)
{
    usleep(ms * 1000);
}

static
millis_time_t millis()
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &amp;ts );
    return ( ts.tv_sec * 1000 + ts.tv_nsec / 1000000L );
}

template&lt;class Proto&gt;
void BlynkApi&lt;Proto&gt;::Init()
{
}

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
millis_time_t BlynkApi&lt;Proto&gt;::getMillis()
{
    return millis();
}

#ifdef BLYNK_NO_INFO

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
void BlynkApi&lt;Proto&gt;::sendInfo() {}

#else

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
void BlynkApi&lt;Proto&gt;::sendInfo()
{
    static const char profile[] BLYNK_PROGMEM =
        BLYNK_PARAM_KV(&quot;ver&quot;    , BLYNK_VERSION)
        BLYNK_PARAM_KV(&quot;h-beat&quot; , TOSTRING(BLYNK_HEARTBEAT))
        BLYNK_PARAM_KV(&quot;buff-in&quot;, TOSTRING(BLYNK_MAX_READBYTES))
#ifdef BLYNK_INFO_DEVICE
        BLYNK_PARAM_KV(&quot;dev&quot;    , BLYNK_INFO_DEVICE)
#endif
#ifdef BLYNK_INFO_CPU
        BLYNK_PARAM_KV(&quot;cpu&quot;    , BLYNK_INFO_CPU)
#endif
#ifdef BLYNK_INFO_CONNECTION
        BLYNK_PARAM_KV(&quot;con&quot;    , BLYNK_INFO_CONNECTION)
#endif
        BLYNK_PARAM_KV(&quot;build&quot;  , __DATE__ &quot; &quot; __TIME__)
    ;
    const size_t profile_len = sizeof(profile)-1;

    char mem_dyn[32];
    BlynkParam profile_dyn(mem_dyn, 0, sizeof(mem_dyn));
    profile_dyn.add_key(&quot;conn&quot;, &quot;Socket&quot;);

    static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_HARDWARE_INFO, 0, profile, profile_len, profile_dyn.getBuffer(), profile_dyn.getLength());
    return;
}

#endif

template&lt;class Proto&gt;
BLYNK_FORCE_INLINE
void BlynkApi&lt;Proto&gt;::processCmd(const void* buff, size_t len)
{
    BlynkParam param((void*)buff, len);
    BlynkParam::iterator it = param.begin();
    if (it &gt;= param.end())
        return;
    const char* cmd = it.asStr();
    const uint16_t cmd16 = *(uint16_t*)cmd;

    if (++it &gt;= param.end())
        return;

    const uint8_t pin = it.asInt();

    switch(cmd16) {

#ifndef BLYNK_NO_BUILTIN

    case BLYNK_HW_PM: {
        while (it &lt; param.end()) {
            ++it;
#ifdef BLYNK_DEBUG
            BLYNK_LOG4(BLYNK_F(&quot;Invalid pin &quot;), pin, BLYNK_F(&quot; mode &quot;), it.asStr());
#endif
            ++it;
        }
    } break;
    case BLYNK_HW_DR: {
        char mem[16];
        BlynkParam rsp(mem, 0, sizeof(mem));
        rsp.add(&quot;dw&quot;);
        rsp.add(pin);
        rsp.add(0); // TODO
        static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_HARDWARE, 0, rsp.getBuffer(), rsp.getLength()-1);
    } break;
    case BLYNK_HW_DW: {
        // Should be 1 parameter (value)
        if (++it &gt;= param.end())
            return;

        // TODO: digitalWrite(pin, it.asInt() ? HIGH : LOW);
    } break;
    case BLYNK_HW_AW: {
        // Should be 1 parameter (value)
        if (++it &gt;= param.end())
            return;

        // TODO: analogWrite(pin, it.asInt());
    } break;

#endif

    case BLYNK_HW_VR: {
        BlynkReq req = { pin };
        WidgetReadHandler handler = GetReadHandler(pin);
        if (handler &amp;&amp; (handler != BlynkWidgetRead)) {
            handler(req);
        } else {
            BlynkWidgetReadDefault(req);
        }
    } break;
    case BLYNK_HW_VW: {
        ++it;
        char* start = (char*)it.asStr();
        BlynkParam param2(start, len - (start - (char*)buff));
        BlynkReq req = { pin };
        WidgetWriteHandler handler = GetWriteHandler(pin);
        if (handler &amp;&amp; (handler != BlynkWidgetWrite)) {
            handler(req, param2);
        } else {
            BlynkWidgetWriteDefault(req, param2);
        }
    } break;
    default:
        BLYNK_LOG2(BLYNK_F(&quot;Invalid HW cmd: &quot;), cmd);
        static_cast&lt;Proto*&gt;(this)-&gt;sendCmd(BLYNK_CMD_RESPONSE, static_cast&lt;Proto*&gt;(this)-&gt;currentMsgId, NULL, BLYNK_ILLEGAL_COMMAND);
    }
}

#endif
