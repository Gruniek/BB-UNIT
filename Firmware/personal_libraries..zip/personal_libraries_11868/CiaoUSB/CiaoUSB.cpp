//  Copyright (C) 2011 Mike Colagrosso
//  http://colagrosso.net
//
//  This file is part of Ciao: Communicate with an Arduino over Bonjour.
//
//  Ciao is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as
//  published by the Free Software Foundation, either version 3 of
//  the License, or (at your option) any later version.
//
//  Ciao is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with Ciao. If not, see
//  &lt;http://www.gnu.org/licenses/&gt;.
//

#include &quot;WProgram.h&quot;
#include &quot;CiaoUSB.h&quot;
#include &lt;stdlib.h&gt;
#include &lt;string.h&gt;

CiaoUsbClass::CiaoUsbClass() {
}

void CiaoUsbClass::begin(char *programName, int port) {
  begin(&quot;arduino&quot;, programName, port);
}

void CiaoUsbClass::begin(char *hostname, char *programName, int listenPort) {
  Serial.println(&quot;&quot;);
  Serial.println(&quot;&quot;);
  Serial.print(&quot;CIAO_HOSTNAME &quot;);
  Serial.println(hostname);
  Serial.print(&quot;CIAO_NAME &quot;);
  Serial.println(programName);
  Serial.print(&quot;CIAO_PORT &quot;);
  Serial.println(listenPort);
}

void CiaoUsbClass::addDisplay(char *label) {
  addDisplay(label, label);
}

void CiaoUsbClass::addDisplay(char *label, char *prefix) {
  Serial.println(&quot;CIAO_DISPLAY&quot;);
  Serial.println(label);
  Serial.println(prefix);
}

void CiaoUsbClass::addButton(char *label) {
  addButton(label, label);
}

void CiaoUsbClass::addButton(char *label, char *send) {
  Serial.println(&quot;CIAO_BUTTON&quot;);
  Serial.println(label);
  Serial.println(send);
}

void CiaoUsbClass::announce() {
  Serial.println(&quot;CIAO_ANNOUNCE&quot;);
}

void CiaoUsbClass::run() {
  // No-op when using USB
}

void CiaoUsbClass::print(const char* s) {
  Serial.print(&quot;CIAO_PRINT &quot;);
  Serial.println(s);
}

void CiaoUsbClass::println(const char* s) {
  Serial.print(&quot;CIAO_PRINTLN &quot;);
  Serial.println(s);
}

void CiaoUsbClass::println(int a) {
  Serial.print(&quot;CIAO_PRINTLN &quot;);
  Serial.println(a);
}


CiaoUsbClass Ciao;