
/*
 Copyright (C) 2011 J. Coliz &lt;maniacbug@ymail.com&gt;

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 version 2 as published by the Free Software Foundation.
 */

#ifndef __RF24_CONFIG_H__
#define __RF24_CONFIG_H__

#if ARDUINO &lt; 100
#include &lt;WProgram.h&gt;
#else
#include &lt;Arduino.h&gt;
#endif

#include &lt;stddef.h&gt;

// Stuff that is normally provided by Arduino
#ifdef ARDUINO
#include &lt;SPI.h&gt;
#else
#include &lt;stdint.h&gt;
#include &lt;stdio.h&gt;
#include &lt;string.h&gt;
extern HardwareSPI SPI;
#define _BV(x) (1&lt;&lt;(x))
#endif

#undef SERIAL_DEBUG
#ifdef SERIAL_DEBUG
#define IF_SERIAL_DEBUG(x) ({x;})
#else
#define IF_SERIAL_DEBUG(x)
#endif

// Avoid spurious warnings
#if 1
#if ! defined( NATIVE ) &amp;&amp; defined( ARDUINO )
#undef PROGMEM
#define PROGMEM __attribute__(( section(&quot;.progmem.data&quot;) ))
#undef PSTR
#define PSTR(s) (__extension__({static const char __c[] PROGMEM = (s); &amp;__c[0];}))
#endif
#endif

// Progmem is Arduino-specific
#ifdef ARDUINO
#include &lt;avr/pgmspace.h&gt;
#define PRIPSTR &quot;%S&quot;
#else
typedef char const char;
typedef uint16_t prog_uint16_t;
#define PSTR(x) (x)
#define printf_P printf
#define strlen_P strlen
#define PROGMEM
#define pgm_read_word(p) (*(p)) 
#define PRIPSTR &quot;%s&quot;
#endif

#endif // __RF24_CONFIG_H__
// vim:ai:cin:sts=2 sw=2 ft=cpp
